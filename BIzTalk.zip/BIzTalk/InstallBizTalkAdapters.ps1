#======================================================================================================
# Silent installation of BizTalk Adapters
# Author : Rajesh Chandrasekaran from Deloitte
# 
# Usage InstallBizTalkAdapters <Adapter Installation Path>
#=======================================================================================================


#====================================================================================
#      Verify parameters
#====================================================================================
if ($args.Count -ne 2 )
{
  Write-Host "Parameters are not good enough, follow one of the below mentioned usage" 
  write-Host "Usage:  InstallBizTalkAdapters.ps1 <Adapter Installation Path test file> <ISO Image File Path>" -ForegroundColor Green
  write-Host "        " 
  exit -1
}

#	BizTalk Installation Folder
$WCFLOBAdapterSDKPath = ""
$WCFAdapterPackx32Path = ""
$WCFAdapterPackx64Path = ""
$EAdapterPackx64Path = ""

$curPath = (Get-Location).ToString()


$FilePath=$args[0]
$values = Get-Content $FilePath | Out-String | ConvertFrom-StringData

$ImagePath=$args[1]
$Mount =Mount-DiskImage -ImagePath $ImagePath -PassThru
$GetDriveLetter= ($Mount | Get-Volume).DriveLetter


$WCFLOBAdapterSDKPath = $values.LOBAdapter64                  
$WCFAdapterPackx32Path = $values.Adapter32
#$WCFAdapterPackx64Path = $values.Adapter64
#$EAdapterPackx64Path= $values.EnterpriseAdapter
$values=""


#====================================================================================================
#
#	Install WCF LOB Adapter  
#
#====================================================================================================
$parameters = "INSTALLDIR=""" + $WCFLOBAdapterSDKPath + """ /Lv* """ + $curPath + "\WCFLOBAdapterInstallation.log"" /qn /norestart"
write-output "Installing WCF LOB Adapter Pack SDK"
$result = (Start-Process $GetDriveLetter":\BizTalk Server\ASDK_x64\AdapterFramework64.MSI" -ArgumentList $parameters  -Wait -Passthru).ExitCode

if($result -ne 0)
{
	Write-Warning "Installation Failed. Instll it manually ......"
	Write-Warning "Exiting installation process..."
	exit -1
}

#====================================================================================================
#
#	Install BizTalk Adapter Pack 32 bit
#
#====================================================================================================
$parameters = "INSTALLDIR=""" + $WCFAdapterPackx32Path + """ /Lv* """ + $curPath + "\BizTalkAdapter32Installationx86.log"" /qn /norestart"
write-output "Installing BizTalk Adapter Pack 32 bit"

$result = (Start-Process $GetDriveLetter":\BizTalk Server\AdapterPack_x86\AdaptersSetup.msi" -ArgumentList $parameters  -Wait -Passthru).ExitCode

if($result -ne 0)
{
	Write-Warning "Installation Failed. Install it manually...."
	Write-Warning "Exiting installation process..."
	exit -1
}


#====================================================================================================
#
#	Install BizTalk Adapter Pack 64 bit
#
#====================================================================================================
$parameters = "INSTALLDIR=""" + $WCFAdapterPackx64Path + """ /Lv* """ + $curPath + "\BizTalkAdapter64Installation.log"" /qn /norestart"
write-output "Installing BizTalk Adapter Pack 64 bit"

$result = (Start-Process $GetDriveLetter":\BizTalk Server\AdapterPack_x64\AdaptersSetup64.msi" -ArgumentList $parameters  -Wait -Passthru).ExitCode

if($result -ne 0)
{
	Write-Warning "Installation Failed. Install it manually......"
	Write-Warning "Exiting installation process..."
	exit -1
}


$pathToConfig='C:\Windows\Microsoft.NET\Framework\v4.0.30319\Config\machine.config'
$Str='<add name="WsseCustomHeaders" type="Ky.Hbe.Interfaces.Common.WsseCustomWCFBehavior.WsseCustomHeaderBehaviorExtension, Ky.Hbe.Interfaces.Common.WsseCustomWCFBehavior, Version=1.0.0.0, Culture=neutral, PublicKeyToken=67a533c80592533d" />
</behaviorExtensions>'

if (!(Get-Content $pathToConfig | Where-Object {$_ -match "WsseCustomHeaders"}))
{ (Get-Content $pathToConfig ).replace('</behaviorExtensions>', "$str") | Set-Content "$pathToConfig"}

$pathToConfig='C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\machine.config'
if (!(Get-Content $pathToConfig | Where-Object {$_ -match "WsseCustomHeaders"}))
{ (Get-Content $pathToConfig ).replace('</behaviorExtensions>', "$str") | Set-Content "$pathToConfig"}


#====================================================================================================
#
#	Install Microsoft BizTalk Adapters for Enterprise Applications
#
#====================================================================================================
$parameters = "INSTALLDIR=""" + $EAdapterPackx64Path + """ /Lv* """ + $curPath + "\BizTalkEAInstallation.log"" /q /passive"
write-output "Installing Microsoft BizTalk Adapters for Enterprise Applications"

$result = (Start-Process $GetDriveLetter":\BizTalk Server\LOB\Msi\Microsoft_BizTalk_Adapters_for_Enterprise_Applications.msi" -ArgumentList $parameters   -Wait -Passthru).ExitCode

if($result -ne 0)
{
	Write-Warning "Installation Failed. Install it manually.........."
	Write-Warning "Exiting installation process..."
        Dismount-DiskImage -ImagePath $ImagePath
	exit -1

}



#====================================================================================================
#
#	Install BizTalk Hotfixes  
#
#====================================================================================================

$Path1 = $curPath +"\BizTalk server 2016 CU6\sqlncli.msi"
$path2 = $curPath + "\BizTalk server 2016 CU6\BTS2016-KB4477494-ENU.exe"

write-output "Installing BizTalk Server 2016 CU6........."
$result = (start-process $Path1 -ArgumentList "/q /passive"  -Passthru -wait).exitCode
$parameters = "/q /passive /log """ + $curPath + "\BizTalkCUInstallation.log"""
$result = (start-process $Path2  -ArgumentList $parameters -Passthru -wait).exitCode

if($result -ne 0)
{
	Write-Warning "Installation of BizTalk Server CU Failed. "
}
else
{
  write-output "Installation of Microsoft BizTalk Server CU6 is completed."
}



        Dismount-DiskImage -ImagePath $ImagePath