#===================================================================================================
# 	Main Installer for Installing BizTalk server
#
#	Author : Rajesh Chandrasekaran from Deloitte  
#
#	This installer calls individual powershell scripts in defined sequence for the installation
#===================================================================================================

#	First define the parameters that will be used in the called powershell scripts
#	This is done so that the changes to the parameters would be done quite easily

#	Local variables used within the script
#	Variable to store whether the last operation is successfull or not.
$LastExitCode = 0
$result = $false
$curPath = (Get-Location).ToString()
#	End Local variables


#	BizTalk Installation Folder
$BizTalkInstallPath = ""

#====================================================================================
#      Verify parameters
#====================================================================================
if ($args.Count -ne 1 )
{
  Write-Host "Installation parameters are not good enough, follow one of the below mentioned usage" 
  write-Host "Usage:  Install.ps1 <BizTalk ISO Image path>" -ForegroundColor Green
  write-Host "        " 
  exit -1
}

$ImagePath=$args[0]
$PrerequisitePath=$curPath + "\Pre-requisites\BtsRedistW2K12R2EN64.cab"   

write-output "Changing StartupType to Manual for Service: Windows Management Instrumentation"
Set-Service �Name "Winmgmt" �Computer . �StartupType �Manual�

$Mount =Mount-DiskImage -ImagePath $ImagePath -PassThru
$GetDriveLetter= ($Mount | Get-Volume).DriveLetter

#write-output ($Mount | Get-Volume).DriveLetter
#Write-output $GetDriveLetter

#====================================================================================================
#
#	Begin Installation
# 
#====================================================================================================

Write-Output "Installing Application Server Roles..."
Write-Output ""
& .\InstallAppServerRole.ps1
if ($LastExitCode -eq 0)
{
	Write-Output "Installed Application Server Roles"
	Write-Output ""
}
else
{
	Write-Output "Installing Application Server Roles Failed..."
	Write-Output ""
#       Dismount-DiskImage -ImagePath $ImagePath
	exit -1

}

Write-Output "Configuring MSDTC..."
Write-Output ""
& .\ConfigureMSDTC.ps1
if ($LastExitCode -eq 0)
{
	Write-Output "Configured MSDTC"
	Write-Output ""
}
else
{
	Write-Output "MSDTC Configuration Failed..."
	Write-Output ""
        Dismount-DiskImage -ImagePath $ImagePath
	exit -1
}



#====================================================================================================
#
#	Install BizTalk Server
#
#====================================================================================================

$exitCode = 0
$arguments = " /QUIET /l  $curPath\BizTalkInstall.log /ADDLOCAL BizTalk,WMI,AdminAndMonitoring,AdminTools,Runtime,MonitoringAndTracking,BizTalkAdminSnapIn,BAMTools,PAM,Engine,MOT,MSMQ,MsEDIAS2,MsEDIAS2StatusReporting,WCFAdapter,BAMPortal,SSOAdmin,SSOServer,RulesEngine,FBAMCLIENT,BAMEVENTAPI /CABPATH $PrerequisitePath /PROMPTRESTART "

write-output $GetDriveLetter
write-output "Started Installing BizTalk Server...."

$exitCode = Start-Process $GetDriveLetter":\BizTalk Server\Setup.exe" -ArgumentList $arguments -wait
write-host $exitCode 
if ($exitCode -ne '')
{
	write-output "Installation of BizTalk server is failed..."
	write-output "Exiting BizTalk Server installation"
        Dismount-DiskImage -ImagePath $ImagePath
	exit -1
}

  write-output "Completed Installation of BizTalk Server...."
  Write-Output ""

Dismount-DiskImage -ImagePath $ImagePath

