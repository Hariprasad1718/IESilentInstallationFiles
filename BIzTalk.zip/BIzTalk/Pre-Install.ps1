

#====================================================================================================
#
#	Install VC++ redistribute, SOAP UI, RM agent
#
#       Author  : Rajesh Chandrasekaran from Deloitte
#====================================================================================================
write-output "Changing StartupType to Disabled for Service: Windows Management Instrumentation"
Set-Service �Name "Winmgmt" �Computer . �StartupType �Disabled�

$curPath = (Get-Location).ToString()

write-output "Installing VC++ Redistribute...... "

$path=$curPath + "\Pre-Requisites\vcredist_x64.exe"

$result = (Start-Process $path -Wait -Passthru).ExitCode
if($result -ne 0)
{
	Write-Warning "Installation of VC++ Redistribute failed."
	Write-Warning "Exiting installation process..."
	exit -1
}

$path = ""
write-output "Installing RM Agent"
$path= $curPath + "\RM-Agent-2015\rm_DeploymentMsdn.exe"      
#RMagentSilentInstall.bat"

$result = (Start-Process $path -Argument "/Passive" -Wait -Passthru).ExitCode
if($result -ne 0)
{
	Write-Warning "Installation of RM Agent failed." 
	Write-Warning "Exiting installation process..."
	exit -1
}
else
{

$path = ""
$path= $curPath + "\RM-Agent-2015\RMagentSilentInstall.bat"

Start-Process $path -Wait -Passthru

write-output "RM Agent Installed" 
}

$path=""

write-output "Installing SOAP UI tool"
$path =$curPath + "\SOAPUI\SoapUI-x64-5.6.0.exe"

$result = (Start-Process $path -Argument "-q" -Wait -Passthru).ExitCode
if($result -ne 0)
{
	Write-Warning "Installation of SOAP UI Failed."
	Write-Warning "Exiting installation process..."
	exit -1
}

If (!(Test-Path "C:\ReceiveAT"))
{ 
   New-Item "C:\ReceiveAT"
}
If (!(Test-Path "C:\SendAT"))
{ 
   New-Item "C:\SendAT"
}


Copy-Item -Path $curPath"\AT\*" -Destination "C:\" -Recurse -passthru


Invoke-Command -ScriptBlock { regedit /i /s "$curPath\Pre-Requisites\TLS1.2.reg"}


Restart-Computer .
