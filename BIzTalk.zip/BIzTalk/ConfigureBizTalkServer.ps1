#======================================================================================================
# Configuration of BizTalk Server part I  ( SSO, Group, Runtime, RuleEngine)
# Author : Rajesh Chandrasekaran from Deloitte
#=======================================================================================================

$exitCode = 0
$curPath = (Get-Location).ToString()
$Date = Get-date -Format "MM dd yyyy HH mm"

#====================================================================================
#      Verify parameters
#====================================================================================
if ($args.Count -ne 1 )
{
  Write-Host " Parameters are not good enough to continue, follow one of the below mentioned usage" 
  write-Host "Usage:  ConfigureBizTalkServer.ps1 <text file contains Service account credentials, BT Domain Groups and BT SQL server and instances>" -ForegroundColor Green
  write-Host "        " 
  exit -1
}


if (!( Test-path $curPath\BizTalkConfigurationMaster.xml )) 
{ 
    write-output "BizTalk Configuration Master file is missing !!!!! " -foreground Black -background white
    exit -1
}


write-host 'Creating BizTalkConfiguration.xml file.......'

if ( Test-path $curPath\BizTalkConfiguration.xml) 
{ 
   Remove-Item $curPath\BizTalkConfiguration.xml
}

##  Do not modify anything in BizTalkConfigurationMaster.xml file.
Copy-Item -Path BizTalkConfigurationMaster.xml   -Destination BizTalkConfiguration.xml

## updating BizTalk service credentials, domain group and SQL server in configuration file.

Write-host "Updating BizTalkConfiguration file with BizTalk SQL Server, Domain Groups and Service accounts....." 

$FilePath=$curPath + "\InputFile_BizTalkConfig.txt"
$values = Get-content -Path $FilePath -Raw | Out-String | ConvertFrom-StringData


[string] $SSOADMINGroup = $values.'{SSOADMINGroup}'
[string] $SSOAffGroup = $values.'{SSOAffGroup}'
[string] $domain='ONE'

[string] $SSOBackupFilePath= $values.'{SSOBackupFilePath}' + "SSOBackup$Date.bak"

[string]$SecretPassword=$values.'{SecretPassword}'

[string]$SSODBServer=$Values.'{SSODBServer}'
[string]$BizTalkMgmtDBServer=$Values.'{BizTalkMgmtDBServer}'
[string]$BizTalkMsgBoxDBServer=$Values.'{BizTalkMsgBoxDBServer}'
[string]$BizTalkDTADBServer=$Values.'{BizTalkDTADBServer}'
[string]$BTSAdminGroup=$Values.'{BTSAdminGroup}'
[string]$BTSOperatorGroup=$Values.'{BTSOperatorGroup}'
[string]$BTSB2BOperatorGRP=$Values.'{BTSB2BOperatorGRP}'
[string]$BTSInProcessDomainGroup=$Values.'{BTSInProcessDomainGroup}'

[string]$BTSIsolatedDomainGroup=$Values.'{BTSIsolatedDomainGroup}'

[string]$BTSBREDBServer=$Values.'{BTSBREDBServer}'

[string] $BizTalkInstallationFilePath= $values.BizTalkInstallationFilePath


$SSOServiceAccount = $Host.ui.PromptForCredential("Logon Credentials","Enter SSO Service Credentials.", $domain + "\", "")
$SSOServiceAccountPassword= [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($SSOServiceAccount.Password))

$SSOServiceAccount=$SSOServiceAccount.UserName

$BTSInProcessServiceAccount = $Host.ui.PromptForCredential("Logon Credentials","Enter In Process Service Credentials.", $domain + "\", "")
$BTSInProcessServicePassword= [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($BTSInProcessServiceAccount.Password))

$BTSInProcessServiceAccount=$BTSInProcessServiceAccount.UserName

$BTSIsolatedServiceAccount = $Host.ui.PromptForCredential("Logon Credentials","Enter Isolated Process Service Credentials.", $domain + "\", "")
$BTSIsolatedServicePassword= [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($BTSIsolatedServiceAccount.Password))

$BTSIsolatedServiceAccount=$BTSIsolatedServiceAccount.UserName

$BTSBREServiceAccount = $Host.ui.PromptForCredential("Logon Credentials","Enter BizTalk BRE Service Credentials.", $domain + "\", "")
$BTSBREServicePassword= [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($BTSBREServiceAccount.Password))

$BTSBREServiceAccount=$BTSBREServiceAccount.UserName

(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{SSOADMINGroup}', "$domain\$SSOADMINGroup") | Set-Content $curPath'\BizTalkConfiguration.xml'

(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{SSOAffGroup}', "$domain\$SSOAffGroup") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{SSOBackupFilePath}', "$SSOBackupFilePath") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{SecretPassword}', "$SecretPassword") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{SSODBServer}', "$SSODBServer") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{SSOServiceAccount}', "$SSOServiceAccount") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{SSOServiceAccountPassword}', "$SSOServiceAccountPassword") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BizTalkMgmtDBServer}', "$BizTalkMgmtDBServer") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BizTalkMsgBoxDBServer}', "$BizTalkMsgBoxDBServer") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BizTalkDTADBServer}', "$BizTalkDTADBServer") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BTSAdminGroup}', "$domain\$BTSAdminGroup") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BTSOperatorGroup}', "$domain\$BTSOperatorGroup") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BTSB2BOperatorGRP}', "$domain\$BTSB2BOperatorGRP") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BTSInProcessDomainGroup}', "$domain\$BTSInProcessDomainGroup") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BTSInProcessServiceAccount}', "$BTSInProcessServiceAccount") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BTSInProcessServicePassword}', "$BTSInProcessServicePassword") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BTSIsolatedDomainGroup}', "$domain\$BTSIsolatedDomainGroup") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BTSIsolatedServiceAccount}', "$BTSIsolatedServiceAccount") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BTSIsolatedServicePassword}', "$BTSIsolatedServicePassword") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BTSBREDBServer}', "$BTSBREDBServer") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BTSBREServiceAccount}', "$domain\$BTSBREServiceAccount") | Set-Content $curPath'\BizTalkConfiguration.xml'
(Get-Content $curPath'\BizTalkConfiguration.xml').replace('{BTSBREServicePassword}', "$BTSBREServicePassword") | Set-Content $curPath'\BizTalkConfiguration.xml'

write-output "Configuring BizTalk server"

$arguments = " /S " + $curPath + "\BizTalkConfiguration.xml" + " /l $curPath\BizTalkconfigurationLog.log"


$exitCode = (Start-Process ($BizTalkInstallationFilePath"\Configuration.exe") -ArgumentList $arguments -wait -passthru).ExitCode


if($exitCode -ne 0)
{
	 Write-Warning "BizTalk is not configured properly... pls configure manually before proceeding further."
}
else
{
	write-output "BizTalk is configured successfully..."
}

