#===================================================================================================
#	This script configure web directory for all Interfaces with help of text file as input which contains list of applications and app pools
#     
#	Author : Rajesh Chandrasekaran from Deloitte
#     
#      
#===================================================================================================
Import-Module WebAdministration



#$FilePath= $args[0]
#$DestinationPath=$args[1]
#$values = Get-Content $FilePath | Out-string 
$domainName ="ONE"
$DestinationPath="D:\inetpub\wwwroot"


<#
#====================================================================================
#      Verify parameters
#====================================================================================
if ($args.Count -ne 2 )
{
  Write-Host " Parameters are not good enough, follow one of the below mentioned usage" 
  write-Host "Usage:  ConfigureIIS.ps1 <Application Pool List as a text file> <Destination path for IIS physical directory such as d:\Inetpub\wwwroot>" -ForegroundColor Green
  write-Host "        " 
  exit -1
}
#>


# Copy Web Applications physical path from Install to IIS web Directory
 Copy-Item -path 'IIS web Folders\*'  -Destination $DestinationPath -Recurse -Force -PassThru





function CreateAppPool ([string] $appPoolName, [string] $AppPoolUserName, [string] $AppPoolPassword)
{

	 # Validation
	    if(($appPoolName -eq $null) -or ($appPoolName -eq ""))
	    {
	        Write-Host "AppPool name is required." -foregroundcolor "Red"
        	return
	    }

         if (Test-Path ("IIS:\AppPools\" + $appPoolName)) {
             Write-Host "The App Pool $appPoolName already exists" -ForegroundColor Yellow
             exit
         }


          $appPool = New-WebAppPool -Name $appPoolName


 	  $pool  = Get-ChildItem IIS:\AppPools | where { $_.name -eq  $appPoolName} | Select-Object -First 1
	  $pool.processmodel.identityType = 3

	  # For IdentityType Custom User
	  $pool.processmodel.username = $AppPoolUserName
	  $pool.processmodel.password = $AppPoolPassword
	  $pool | Set-Item -Force
          
          $spool = ""
	Write-Output "The Application Pool "$appPoolName" has been successfully created."


}

Function CreateAppPool {
         Param([string] $appPoolName)
         if(Test-Path ("IIS:\AppPools\" + $appPoolName)) {
             Write-Host "The App Pool $appPoolName already exists" -ForegroundColor Yellow
             exit
         }
         $appPool = New-WebAppPool -Name $appPoolName
     }

Function CreateWebDirectoryAndAssignAppPool 
{
          Param([string] $WebSiteName,
                [string] $WebAppName,
                [string] $AppPoolName)

         if (!(Test-Path ("IIS:\AppPools\" + $AppPoolName)) )
	 {
             Write-Host "The App Pool $AppPoolName doesn't exists." -ForegroundColor Yellow
             return
         }

          if (! (Test-Path ("IIS:\Sites\$WebSiteName\$WebAppName")))
	 {
              Write-Host "Web App $WebAppName doesn't exists" -ForegroundColor Yellow
              return
          }

           ConvertTo-WebApplication -ApplicationPool $AppPoolName -PSPath "IIS:\Sites\$WebSiteName\$WebAppName"


}

     Write-Host "Creating List of Application Pool....."
	# Get user credentials through input

	$AppPoolCredentials = $Host.ui.PromptForCredential("Logon Credentials","This account must be part of BizTalk Server Host group and proper SQL Server permissions.", $domainName + "\", "");

	[String]$AppPoolCredentialsPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($AppPoolCredentials.Password)); 

	CreateAppPool "AJ Inbound" $AppPoolCredentials.UserName $AppPoolCredentialsPassword
	CreateAppPool "AJ Outbound" $AppPoolCredentials.UserName $AppPoolCredentialsPassword
	CreateAppPool "ERDC" $AppPoolCredentials.UserName $AppPoolCredentialsPassword
	CreateAppPool "EDRS" $AppPoolCredentials.UserName $AppPoolCredentialsPassword
	CreateAppPool "FDSH Inbound" $AppPoolCredentials.UserName $AppPoolCredentialsPassword
	CreateAppPool "FDSH Outbound" $AppPoolCredentials.UserName $AppPoolCredentialsPassword
	CreateAppPool "MMIS Outbound" $AppPoolCredentials.UserName $AppPoolCredentialsPassword
	CreateAppPool "OregonAccess" $AppPoolCredentials.UserName $AppPoolCredentialsPassword
	CreateAppPool "PaymentSystems" $AppPoolCredentials.UserName $AppPoolCredentialsPassword
	CreateAppPool "SE Inbound" $AppPoolCredentials.UserName $AppPoolCredentialsPassword
	CreateAppPool "SE Outbound" $AppPoolCredentials.UserName $AppPoolCredentialsPassword
	CreateAppPool "SOLQ Outbound" $AppPoolCredentials.UserName $AppPoolCredentialsPassword

	# Create WebDirectory and assign App Pool
     Write-Host "Creating List of Web Directory(s) and assign apppool....."
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "AJMasterService" "AJ Inbound"
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "EDRSAddDisqualificationSvc" "EDRS"
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "EDRSContactDetailsWebService" "EDRS"
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "EDRSDeleteDisqualification" "EDRS" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "EDRSEditDisqualification" "EDRS" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "EDRSOnlineSearch" "EDRS" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "ERDCRealTime" "ERDC" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "FFMMECCheck" "FDSH Inbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "InitialVerificationWcfService" "FDSH Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "InternalMECCheckService" "MMIS Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "JOBSPlusService"  "AJ Inbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "Ky.Hbe.Interfaces.Fdh.FARService" "FDSH Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "Ky.Hbe.Interfaces.Fdh.PIService" "FDSH Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "NonESIMECWcfService" "FDSH Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "NotifyCasesWcfService" "FDSH Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "OregonAccess" "OregonAccess" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "PaymentService" "PaymentSystems" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "PaymentSystems" "PaymentSystems" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "ReceiveAccountTransfer" "FDSH Inbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "SELGInboundService" "SE Inbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "SELGsvc" "SE Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "SSACompositeWCFService" "FDSH Outbound"
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "SSASOLQStandaloneservice" "SOLQ Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "SupportServiceWcfService" "AJ Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "TANFCCRealTime" "AJ Inbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "VCIWcfService" "FDSH Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "VLPStep1aWcfService" "FDSH Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "VLPStep1bWcfService" "FDSH Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "WcfOrchPolling" "FDSH Outbound" 
	CreateWebDirectoryAndAssignAppPool "Default Web Site" "WCFSOLQService" "SOLQ Outbound" 
	
  
