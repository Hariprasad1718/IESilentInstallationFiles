#======================================================================================================
#  This script creates and configure BizTalk Host and Host Instance
#
#  Author : Rajesh Chandrasekaran from Deloitte
#=======================================================================================================

#====================================================================================
#      Verify parameters
#====================================================================================
if ($args.Count -ne 1 )
{
  Write-Host " Parameters are not good enough to continue, follow one of the below mentioned usage" 
  write-Host "Usage:  ConfigureHosts_HostInstance.ps1 <Host and host instances configuration file>" -ForegroundColor Green
  write-Host "        " 
  exit -1
}

#	Get the configuration file
$FilePath=$args[0]
$values = Get-content -Path $FilePath -Raw | Out-String | ConvertFrom-StringData


#############################################################
# Global Variables
#############################################################

[string] $bizTalkDbServer = $values.DBServer
[string] $bizTalkDbName = $values.DBName
[string] $IPDomainGroup = $values.IPDomainGroup
[string] $IsoDomainGroup = $values.IsoDomainGroup

[string] $receiveHostName = $values.RH
[string] $sendHostName = $values.SH
[string] $processingHostName = $values.OH
[string] $trackingHostName = $values.TH
[string] $SQLsendHostName = $values.SQLSH
[string] $SQLReceiveHostName = $values.SQLRH
[string] $IISReceiveHostName = $values.IISRH
[string] $domain='ONE'

$values=""

#############################################################
# This function will create a new BizTalk Host
# HostType: In-process	1, Isolated	2
#############################################################

function CreateBizTalkHost(
    [string]$hostName, 
    [int]$hostType, 
    [string]$ntGroupName, 
    [bool]$authTrusted, 
    [bool]$isTrackingHost, 
    [bool]$is32BitOnly)
{

    try
    {
        [System.Management.ManagementObject]$objHostSetting = ([WmiClass]"root/MicrosoftBizTalkServer:MSBTS_HostSetting").CreateInstance()

        $objHostSetting["Name"] = $hostName
        $objHostSetting["HostType"] = $hostType
        $objHostSetting["NTGroupName"] = $ntGroupName
        $objHostSetting["AuthTrusted"] = $authTrusted
        $objHostSetting["IsHost32BitOnly"] = $is32BitOnly 
        $objHostSetting["HostTracking"] = $isTrackingHost

        $putOptions = new-Object System.Management.PutOptions
        $putOptions.Type = [System.Management.PutType]::CreateOnly;

        [Type[]] $targetTypes = New-Object System.Type[] 1
        $targetTypes[0] = $putOptions.GetType()

        $sysMgmtAssemblyName = "System.Management"
        $sysMgmtAssembly = [System.Reflection.Assembly]::LoadWithPartialName($sysMgmtAssemblyName)
        $objHostSettingType = $sysMgmtAssembly.GetType("System.Management.ManagementObject")

        [Reflection.MethodInfo] $methodInfo = $objHostSettingType.GetMethod("Put", $targetTypes)
        $methodInfo.Invoke($objHostSetting, $putOptions)
		
		Write-Host "Host $hostName was successfully created" -Fore DarkGreen
    }
    catch [System.Management.Automation.RuntimeException]
    {
		if ($_.Exception.Message.Contains("Another BizTalk Host with the same name already exists in the BizTalk group.") -eq $true)
        {
			Write-Host "$hostName can't be created because another BizTalk Host with the same name already exists in the BizTalk group." -Fore White
        }
		else{ write-Error "$hostName host could not be created: $_.Exception.ToString()"}
    }
}



#############################################################
# This function will create a new BizTalk Host Instance
#############################################################
function CreateBizTalkHostInstance(
	[string]$hostName,
	[string]$serverName,
	[string]$username,
	[string]$password)
{
    try
    {
        [System.Management.ManagementObject]$objServerHost = ([WmiClass]"root/MicrosoftBizTalkServer:MSBTS_ServerHost").CreateInstance()

        $objServerHost["HostName"] = $hostName
        $objServerHost["ServerName"] = $serverName
        $objServerHost.Map()

        [System.Management.ManagementObject]$objHostInstance = ([WmiClass]"root/MicrosoftBizTalkServer:MSBTS_HostInstance").CreateInstance()

        $name = "Microsoft BizTalk Server " + $hostName + " " + $serverName
        $objHostInstance["Name"] = $name
        $objHostInstance.Install($username, $password, $true)

		Write-Host "HostInstance $hostName was mapped and installed successfully. Mapping created between Host: $hostName and Server: $Server);" -Fore Green
    }
    catch [System.Management.Automation.RuntimeException]
    {
		if ($_.Exception.Message.Contains("Another object with the same key properties already exists.") -eq $true)
        {
			Write-Host "$hostName host instance can't be created because another object with the same key properties already exists." -Fore DarkRed
        }
		else{  write-Error "$hostName host instance on server $Server could not be created: $_.Exception.ToString()" }
    }
}

#############################################################
# This function will create a handler for a specific 
# adapter on the new host, so these get used for processing.
# [direction]: 'Receive','Send'
#############################################################
function CreateBizTalkAdapterHandler(
	[string]$adapterName,
	[string]$direction,
	[string]$hostName,
	[string]$originalDefaulHostName,
	[boolean]$isDefaultHandler,
	[boolean]$removeOriginalHostInstance)
{
	if($direction -eq 'Receive')
	{
		[System.Management.ManagementObject]$objAdapterHandler = ([WmiClass]"root/MicrosoftBizTalkServer:MSBTS_ReceiveHandler").CreateInstance()
		$objAdapterHandler["AdapterName"] = $adapterName
	    $objAdapterHandler["HostName"] = $hostName
	}
	else
	{
		[System.Management.ManagementObject]$objAdapterHandler = ([WmiClass]"root/MicrosoftBizTalkServer:MSBTS_SendHandler2").CreateInstance()
		$objAdapterHandler["AdapterName"] = $adapterName
	    $objAdapterHandler["HostName"] = $hostName
	    $objAdapterHandler["IsDefault"] = $isDefaultHandler
	}
		
    try
    {
        $putOptions = new-Object System.Management.PutOptions
        $putOptions.Type = [System.Management.PutType]::CreateOnly;

        [Type[]] $targetTypes = New-Object System.Type[] 1
        $targetTypes[0] = $putOptions.GetType()

        $sysMgmtAssemblyName = "System.Management"
        $sysMgmtAssembly = [System.Reflection.Assembly]::LoadWithPartialName($sysMgmtAssemblyName)
        $objAdapterHandlerType = $sysMgmtAssembly.GetType("System.Management.ManagementObject")

        [Reflection.MethodInfo] $methodInfo = $objAdapterHandlerType.GetMethod("Put", $targetTypes)
        $methodInfo.Invoke($objAdapterHandler, $putOptions)

        Write-Host "$adapterName $direction Handler for $hostName was successfully created" -Fore DarkGreen
    }
    catch [System.Management.Automation.RuntimeException]
    {
		if ($_.Exception.Message.Contains("The specified BizTalk Host is already a receive handler for this adapter.") -eq $true)
        {  Write-Host "$hostName is already a $direction Handler for $adapterName adapter." -Fore DarkRed  }
		elseif($_.Exception.Message.Contains("The specified BizTalk Host is already a send handler for this adapter.") -eq $true)
        { 	Write-Host "$hostName is already a $direction Handler for $adapterName adapter." -Fore DarkRed         }
		else { write-Error "$adapterName $direction Handler for $hostName could not be created: $_.Exception.ToString()" }
    }


}




function ConfiguringBizTalkServerHostAndHostInstances
{

 
try
{
    [string]$defaultHostName = 'BizTalkServerApplication'

       
       	write-Output "Configuring Host ......"
	
       # creating In process Host 
	CreateBizTalkHost $receiveHostName 1 $IPDomainGroup $false $false $false
	CreateBizTalkHost $processingHostName 1 $IPDomainGroup $false $false $false
	CreateBizTalkHost $sendHostName 1 $IPDomainGroup $false $false $false
	CreateBizTalkHost $SQLsendHostName 1 $IPDomainGroup $false $false $false
	CreateBizTalkHost $trackingHostName 1 $IPDomainGroup $false $true $false
	CreateBizTalkHost $SQLReceiveHostName 1 $IPDomainGroup $false $false $false

       # creating Isolated Host 
	CreateBizTalkHost $IISReceiveHostName 2 $IsoDomainGroup  $false $false $false


       # Set adapters that should be handled by receiving host instance
	CreateBizTalkAdapterHandler 'FILE' 'Receive' $receiveHostName $defaultHostName $false $false
	CreateBizTalkAdapterHandler 'WCF-Custom' 'Receive' $receiveHostName $defaultHostName $false $false 

	# Set adapters that should be handled by Send host instance
	CreateBizTalkAdapterHandler 'WCF-Custom' 'Send' $sendHostName  $defaultHostName $false $false 
        CreateBizTalkAdapterHandler 'WCF-BasicHttp' 'Send' $sendHostName  $defaultHostName $false $false 
        CreateBizTalkAdapterHandler 'WCF-WebHttp' 'Send' $sendHostName  $defaultHostName $false $false 

	# Set adapters that should be handled by SQLSend host instance
	CreateBizTalkAdapterHandler 'WCF-Custom' 'Send' $SQLsendHostName  $defaultHostName $false $false 

	# Set adapters that should be handled by SQLReceive host instance
	CreateBizTalkAdapterHandler 'WCF-Custom' 'Receive' $SQLReceiveHostName $defaultHostName $false $false 

	# Set adapters that should be handled by IISReceive host instance
	CreateBizTalkAdapterHandler 'WCF-WebHttp' 'Receive' $IISReceiveHostName  $defaultHostName $false $false 
        CreateBizTalkAdapterHandler 'WCF-BasicHttp' 'Receive' $IISReceiveHostName $defaultHostName $false $false 



	write-Output "Configuring Host Instances......"


	$InProcessHostCredentials = $Host.ui.PromptForCredential("Logon Credentials","Enter In Process Host Credentials. ", $domain + "\", "");
	[String]$InProcessCredentialsPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($InProcessHostCredentials.Password)); 



	# Create a host instance
	CreateBizTalkHostInstance $receiveHostName $bizTalkServerName $InProcessHostCredentials.UserName $InProcessCredentialsPassword
	CreateBizTalkHostInstance $processingHostName $bizTalkServerName $InProcessHostCredentials.UserName $InProcessCredentialsPassword
	CreateBizTalkHostInstance $sendHostName $bizTalkServerName $InProcessHostCredentials.UserName $InProcessCredentialsPassword
	CreateBizTalkHostInstance $SQLsendHostName $bizTalkServerName $InProcessHostCredentials.UserName $InProcessCredentialsPassword
	CreateBizTalkHostInstance $SQLReceiveHostName $bizTalkServerName $InProcessHostCredentials.UserName $InProcessCredentialsPassword

	# Create a host instance for tracking
	CreateBizTalkHostInstance $trackingHostName $bizTalkServerName $InProcessHostCredentials.UserName $InProcessCredentialsPassword

	$IsoHostCredentials = $Host.ui.PromptForCredential("Logon Credentials","Enter Isolated Host Credentials. ", $domain + "\", "");
	[String]$IsoHostCredentialsPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($IsoHostCredentials.Password)); 


	CreateBizTalkHostInstance $IISReceiveHostName $bizTalkServerName $IsoHostCredentials.UserName $IsoHostCredentialsPassword

  }	
    catch 
    {
       $ErrorMessage = $_.Exception.Message
       $FailedItem = $_.Exception.ItemName
       Write-Host "Exception occurred during Host, Host instance configuration....... $errorMessage   $FailedItem" -Fore white  -Background black
    }

}





Write-Host "Starting configuring BizTalk Host and Host Instances..." -Fore Green

$bizTalkServerName = $(Get-WmiObject Win32_Computersystem).name

Write-Host "Creating hosts and host instances..." -Fore Green

try 
{
write-host "before calling function: " $receiveHostName , $IPDomainGroup 

ConfiguringBizTalkServerHostAndHostInstances
}
Catch
{
  exit -1
}

Write-Host "BizTalk Host and Host Instances are now configured." -Fore Green

