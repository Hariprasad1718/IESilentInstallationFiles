﻿## EXECUTE THIS SCRIPT FROM MANAGEMENT SERVER INSTALLTION PATH 

## 1. PLACE THE (univiewer_console.iss) INPUT RESPONSE FILE IN THE PATH (D:\) D DRIVE.
## 2. FILL THE FOLLOWING PARAMETERS


##------------------------------------------------------------------------------PARAMETERS---------------------------------------------------------------------------------------------------------------------------------------------------------------------

$ManagementserverInstallationPath="D:\Installables\DU_Managementserver"

$Java_InstallationExecutable="D:\Installables\DU_Managementserver"

$JDBC_Drive="D:\Installables\sqljdbc_4.1\enu\sqljdbc41.jar"

$ConsoleInstallationPath="D:\Installables\DU_Console"

$NodeInstallationPath="D:\Installables\DU_Nodeinstall"

$Java_Path="D:\java\jre"

$Managementserver_node="Management server"

$Managementserver_host="Management server"

$centraladminuser="admin"

$centralpassord="admin123"

$database_host="Database server"

$database_port="port"

$database_name="DU"

$database_instance="MSSQLSERVER"

$database_user="username"

$database_password="password"

$company="ONEDEV"

$Nodes= "Node1 server","Node2 server"  ##-- PASS THE NODES LIST HERE


##------------------------------------------------------------------------SCRIPT STARTS FROM HERE-------------------------------------------------------------------------------------------------------------------------------------------------


#-------Creating the Ports in Management server and Node servers----------------------------------------

New-NetFirewallRule -DisplayName "DU" -Direction Outbound -LocalPort 4184,10600-10700 -Protocol TCP -Action Allow

New-NetFirewallRule -DisplayName "DU" -Direction Inbound -LocalPort 4184,10600-10700 -Protocol TCP -Action Allow

Write-Output Firewall Ports are Open in Management Server

foreach ($Node in $Nodes)

{
   Invoke-Command -ComputerName $Node -ScriptBlock {(New-NetFirewallRule -DisplayName "DU" -Direction Outbound -LocalPort 4184,10600-10700 -Protocol TCP -Action Allow),(New-NetFirewallRule -DisplayName "DU" -Direction Inbound -LocalPort 4184,10600-10700 -Protocol TCP -Action Allow)}

   Write-Output Firewall Ports are Open in $Node Servers
}

Write-Output Firewall Ports are Open in Node Servers


##--------Installing Java in the Management Server-------------------------------------------------------

Write-Output Installing Java in the Management server

Start-Process $Java_InstallationExecutable\.\jre-8u281-windows-x64.exe '/s REBOOT=0 SPONSORS=0 AUTO_UPDATE=0 INSTALLDIR=D:\java\jre' -wait

Write-Output Java is installed in the Management server


##-------Installing Dollar Universe Management Server----------------------------------------------------

Write-Output Installing the Dollar Universe Management server

cd $ManagementserverInstallationPath

start-process -wait uniinstaller.bat "-install jrepath=$Java_Path installdir=D:\AUTOMIC\univiewer_server node=$Managementserver_node centralhost=$Managementserver_host centralport=4184 sslport=4443 centrallogin=$centraladminuser centralpasswd=$centralpassord mode_install=s type_database=m jdbc_driver=$JDBC_Drive database_host=$database_host database_port=$database_port database_name=$database_name database_instance=$database_instance db_uvms_user_name=$database_user db_uvms_user_passwd=$database_password"

Write-Output The Dollar Universe Management server is installed


##-------Installing Dollar Universe Nodes----------------------------------------------------------------


foreach ($Node in $Nodes) {

Write-Output Installing Dollar Universe Node $Node...

Copy-Item "$NodeInstallationPath" -Destination "\\$Node\D$\Installables\DU_Nodeinstall"  -Recurse

Start-Sleep -s 10

$ScriptBlock = {param($company,$Node,$Managementserver_host,$centraladminuser,$centralpassord) `
Invoke-Expression -Command: "cmd.exe /c 'D:\Installables\DU_Nodeinstall\uniinstaller.bat' -install company=$company node=$Node nodehost=$Node installdir=D:\AUTOMIC\univiewer_Node execpath=D:\AUTOMIC\univiewer_Node\bin logpath=D:\AUTOMIC\univiewer_Node\log uvmsnow=y centralhost=$Managementserver_host centralport=4184 centrallogin=$centraladminuser centralpasswd=$centralpassord"}

Invoke-Command   $ScriptBlock -ComputerName $Node -ArgumentList $company,$Node,$Managementserver_host,$centraladminuser,$centralpassord

Write-Output Dollar Universe Node is Installed in $Node
}




#------ Installing Dollar Universe Console--------------------------------------------------------------

Write-Output Installing the Dollar Universe Univiewer Console in the server

cd $ConsoleInstallationPath

start-process -wait  $ConsoleInstallationPath\univiewer_console.exe -argumentlist '/s /f1"D:\univiewer_console.iss" /f2"D:\univiewer_console.log"'

Start-Sleep -s 60

Write-Output The Dollar Universe Univiewer Console installation is complete in the server
