USE [msdb]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF object_id(N'fn_SQLServerBackupDir', N'FN') IS NOT NULL
    DROP FUNCTION fn_SQLServerBackupDir
GO

CREATE FUNCTION [dbo].[fn_SQLServerBackupDir]() 
RETURNS NVARCHAR(4000) 
AS 
BEGIN 

   DECLARE @path NVARCHAR(4000) 

   EXEC master.dbo.xp_instance_regread 
            N'HKEY_LOCAL_MACHINE', 
            N'Software\Microsoft\MSSQLServer\MSSQLServer',N'BackupDirectory', 
            @path OUTPUT,  
            'no_output' 
   RETURN @path 

END;

GO


USE [msdb]
GO
DECLARE @operator  varchar(20)
SELECT @operator = name FROM msdb.dbo.sysoperators  WHERE (name = N'dba')
IF (@operator IS  NULL)
BEGIN
  EXEC msdb.dbo.sp_add_operator @name=N'dba', 
		@enabled=1, 
		@weekday_pager_start_time=90000, 
		@weekday_pager_end_time=180000, 
		@saturday_pager_start_time=90000, 
		@saturday_pager_end_time=180000, 
		@sunday_pager_start_time=90000, 
		@sunday_pager_end_time=180000, 
		@pager_days=0, 
		@email_address=N'sbatakurki@deloitte.com;serlapati@deloitte.com', 
		@category_name=N'[Uncategorized]'
END
GO

USE [msdb]
GO
BEGIN TRANSACTION

DECLARE @jobId_temp binary(16)

SELECT @jobId_temp = job_id FROM msdb.dbo.sysjobs WHERE (name = N'J1_Full_Backup')
IF (@jobId_temp IS NOT NULL)
BEGIN
    EXEC msdb.dbo.sp_delete_job @jobId_temp
END


DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'J1_Full_Backup', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=3, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job takes full backup of all databases', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'S1_Full_Backup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @backupFileName varchar(100), @backupDirectory varchar(100),
	@databaseDataFilename varchar(100), @databaseLogFilename varchar(100),
	@databaseDataFile varchar(100), @databaseLogFile varchar(100),
	@databaseName varchar(100), @execSql varchar(1000), @cur cursor, @dbbkp_rowno int=0

set @backupDirectory =[dbo].[fn_SQLServerBackupDir]() 

select @dbbkp_rowno = max(r) from ( 
select row_number() over (partition by s.database_name,convert(varchar(max),s.backup_start_date,110)  order by s.backup_start_date) as r
FROM msdb.dbo.backupset s
INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id
where m.physical_device_name LIKE ''%''+@backupDirectory+''%''
and convert(varchar(max),s.backup_start_date,110) = convert(varchar(max),getdate(),110))x


  set @dbbkp_rowno = isnull(@dbbkp_rowno,0)


 

set @cur = cursor fast_forward for 
select name from sysdatabases where dbid > 4
open @cur
fetch next from @cur into @databaseName 
 while @@fetch_status =0
 
begin

  set @backupFileName = @backupDirectory + ''\''+@databaseName + ''_'' + convert(varchar(max),getdate(),110) +''_''+ convert(varchar,@dbbkp_rowno+1) + ''.bak''

   select	@databaseDataFile = rtrim([Name]),
	@databaseDataFilename = rtrim([Filename]) 
   from	master.dbo.sysaltfiles as files
	inner join
	master.dbo.sysfilegroups as groups
	on
	files.groupID = groups.groupID
   where	DBID = (
		select	dbid
		from	master.dbo.sysdatabases
		where	[Name] = @databaseName
	)

select	@databaseLogFile = rtrim([Name]),
	@databaseLogFilename = rtrim([Filename])
from	master.dbo.sysaltfiles as files
where	DBID = (
		select	dbid
		from	master.dbo.sysdatabases
		where	[Name] = @databaseName
	)
	and
	groupID = 0

--print ''Backing up "'' + @databaseName + ''" database to "'' + @backupFileName + ''" with ''
--print ''  data file "'' + @databaseDataFile + ''" located at "'' + @databaseDataFilename + ''"''
--print ''  log file "'' + @databaseLogFile + ''" located at "'' + @databaseLogFilename + ''"''

set @execSql = ''
backup database ['' + @databaseName + '']
to disk = '''''' + @backupFileName + '''''' 
with
  noformat,
  noinit,
  name = '''''' + @databaseName + '' backup'''',
  norewind,
  nounload,COMPRESSION,
  COPY_ONLY,
  skip''

exec(@execSql)

  fetch next from @cur into @databaseName 
 end

close @cur
deallocate @cur', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'J1_Full_Backup_schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=64, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151019, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'416ce6c4-e8c1-40bf-b51c-4c9f6c12205d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

BEGIN TRANSACTION
DECLARE @jobId_temp binary(16)

SELECT @jobId_temp = job_id FROM msdb.dbo.sysjobs WHERE (name = N'J2_Differential_Backup')
IF (@jobId_temp IS NOT NULL)
BEGIN
    EXEC msdb.dbo.sp_delete_job @jobId_temp
END

DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'J2_Differential_Backup', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=3, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job will take Differentail backup every day for all databases', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'S1_Differential_Backup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @backupFileName varchar(100), @backupDirectory varchar(100),
	@databaseDataFilename varchar(100), @databaseLogFilename varchar(100),
	@databaseDataFile varchar(100), @databaseLogFile varchar(100),
	@databaseName varchar(100), @execSql varchar(1000), @cur cursor, @dbbkp_rowno int=0
set @backupDirectory =[dbo].[fn_SQLServerBackupDir]() 
select @dbbkp_rowno = max(r) from ( 
select row_number() over (partition by s.database_name,convert(varchar(max),s.backup_start_date,110)  order by convert(varchar(max),s.backup_start_date,110)) as r
FROM msdb.dbo.backupset s
INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id
where m.physical_device_name LIKE ''%''+@backupDirectory+''%''
and convert(varchar(max),s.backup_start_date,110) = convert(varchar(max),getdate(),110))x

  set @dbbkp_rowno = isnull(@dbbkp_rowno,0)

--  if @dbbkp_rowno > 0 
  begin 
set @backupDirectory =[dbo].[fn_SQLServerBackupDir]()  

set @cur = cursor fast_forward for 
select name from sysdatabases where dbid > 4
open @cur
fetch next from @cur into @databaseName 
 while @@fetch_status =0
 
begin

  set @backupFileName = @backupDirectory +''\''+ @databaseName + ''_'' + convert(varchar(max),getdate(),110) +''_DIFF_''+ convert(varchar,@dbbkp_rowno) + ''.bak''
select	@databaseDataFile = rtrim([Name]),
	@databaseDataFilename = rtrim([Filename]) 
   from	master.dbo.sysaltfiles as files
	inner join
	master.dbo.sysfilegroups as groups
	on
	files.groupID = groups.groupID
   where	DBID = (
		select	dbid
		from	master.dbo.sysdatabases
		where	[Name] = @databaseName
	)

select	@databaseLogFile = rtrim([Name]),
	@databaseLogFilename = rtrim([Filename])
from	master.dbo.sysaltfiles as files
where	DBID = (
		select	dbid
		from	master.dbo.sysdatabases
		where	[Name] = @databaseName
	)
	and
	groupID = 0

--print ''Backing up "'' + @databaseName + ''" database to "'' + @backupFileName + ''" with ''
--print ''  data file "'' + @databaseDataFile + ''" located at "'' + @databaseDataFilename + ''"''
--print ''  log file "'' + @databaseLogFile + ''" located at "'' + @databaseLogFilename + ''"''

set @execSql = ''
backup database ['' + @databaseName + '']
to disk = '''''' + @backupFileName + '''''' 
with
  noformat,
  differential,
  name = '''''' + @databaseName + '' backup'''',
  norewind,
  nounload,COPY_ONLY,COMPRESSION,
  skip''

exec(@execSql)

   

  fetch next from @cur into @databaseName 
 end

close @cur
deallocate @cur
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'S1_Differential_Backup_schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=4, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20151020, 
		@active_end_date=99991231, 
		@active_start_time=220000, 
		@active_end_time=235959, 
		@schedule_uid=N'fe2d3ca3-ab39-4924-b25d-5c6457209b6d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [J3_Transaction_log_Backup]    Script Date: 3/20/2017 11:23:25 AM ******/
BEGIN TRANSACTION
DECLARE @jobId_temp binary(16)

SELECT @jobId_temp = job_id FROM msdb.dbo.sysjobs WHERE (name = N'J3_Transaction_log_Backup')
IF (@jobId_temp IS NOT NULL)
BEGIN
    EXEC msdb.dbo.sp_delete_job @jobId_temp
END
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 3/20/2017 11:23:25 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'J3_Transaction_log_Backup', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=3, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job takes transactional log backup for all databases', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [S1_Transactional_log_Backup]    Script Date: 3/20/2017 11:23:25 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'S1_Transactional_log_Backup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @backupFileName varchar(100), @backupDirectory varchar(100),
	@databaseDataFilename varchar(100), @databaseLogFilename varchar(100),
	@databaseDataFile varchar(100), @databaseLogFile varchar(100),
	@databaseName varchar(100), @execSql varchar(1000), @cur cursor, @dbbkp_rowno int=0
set @backupDirectory =[dbo].[fn_SQLServerBackupDir]() 
select @dbbkp_rowno = max(r) from ( 
select row_number() over (partition by s.database_name,convert(varchar(max),s.backup_start_date,110)  order by convert(varchar(max),s.backup_start_date,110)) as r
FROM msdb.dbo.backupset s
INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id
where m.physical_device_name LIKE ''%''+@backupDirectory+''%''
and convert(varchar(max),s.backup_start_date,110) = convert(varchar(max),getdate(),110))x

  set @dbbkp_rowno = isnull(@dbbkp_rowno,0)

--  if @dbbkp_rowno > 0 
  begin 
set @backupDirectory =[dbo].[fn_SQLServerBackupDir]()  

set @cur = cursor fast_forward for 
select name from sys.databases where database_id > 4 and recovery_model < 3
open @cur
fetch next from @cur into @databaseName 
 while @@fetch_status =0
 
begin

  set @backupFileName = @backupDirectory +''\'' + @databaseName + ''_'' + convert(varchar(max),getdate(),110) +''_LOG_''+ convert(varchar,@dbbkp_rowno) + ''.trn''
select	@databaseDataFile = rtrim([Name]),
	@databaseDataFilename = rtrim([Filename]) 
   from	master.dbo.sysaltfiles as files
	inner join
	master.dbo.sysfilegroups as groups
	on
	files.groupID = groups.groupID
   where	DBID = (
		select	dbid
		from	master.dbo.sysdatabases
		where	[Name] = @databaseName
	)

select	@databaseLogFile = rtrim([Name]),
	@databaseLogFilename = rtrim([Filename])
from	master.dbo.sysaltfiles as files
where	DBID = (
		select	dbid
		from	master.dbo.sysdatabases
		where	[Name] = @databaseName
	)
	and
	groupID = 0

--print ''Backing up "'' + @databaseName + ''" database to "'' + @backupFileName + ''" with ''
--print ''  data file "'' + @databaseDataFile + ''" located at "'' + @databaseDataFilename + ''"''
--print ''  log file "'' + @databaseLogFile + ''" located at "'' + @databaseLogFilename + ''"''

set @execSql = ''
backup log ['' + @databaseName + '']
to disk = '''''' + @backupFileName + '''''' 
''

exec(@execSql)

   

  fetch next from @cur into @databaseName 
 end

close @cur
deallocate @cur
end', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'S1_Transactional_log_backup_schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=6, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20151020, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=180000, 
		@schedule_uid=N'4747e71b-0450-490b-95f7-f5958f626524'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [J4_Check_db_Integrity]    Script Date: 3/20/2017 11:23:25 AM ******/
BEGIN TRANSACTION
DECLARE @jobId_temp binary(16)

SELECT @jobId_temp = job_id FROM msdb.dbo.sysjobs WHERE (name = N'J4_Check_db_Integrity')
IF (@jobId_temp IS NOT NULL)
BEGIN
    EXEC msdb.dbo.sp_delete_job @jobId_temp
END
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 3/20/2017 11:23:25 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'J4_Check_db_Integrity', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=3, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job check the db integrity for all databases', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 3/20/2017 11:23:25 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d master -Q "EXECUTE dbo.DatabaseIntegrityCheck @Databases = ''USER_DATABASES'',@CheckCommands = ''CHECKDB'',@ExtendedLogicalChecks = ''Y''" -b', 
		@flags=32
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'S1_Check_db_Integrity_schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151020, 
		@active_end_date=99991231, 
		@active_start_time=20000, 
		@active_end_time=235959, 
		@schedule_uid=N'acf2cfc8-ce7e-401e-9b58-720ce0f08aec'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [J5_Rebuild_or_Reorganize_Index]    Script Date: 3/20/2017 11:23:25 AM ******/
BEGIN TRANSACTION
DECLARE @jobId_temp binary(16)

SELECT @jobId_temp = job_id FROM msdb.dbo.sysjobs WHERE (name = N'J5_Rebuild_or_Reorganize_Index')
IF (@jobId_temp IS NOT NULL)
BEGIN
    EXEC msdb.dbo.sp_delete_job @jobId_temp
END
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 3/20/2017 11:23:25 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'J5_Rebuild_or_Reorganize_Index', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=3, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [S1_rebuild_or_reorganize]    Script Date: 3/20/2017 11:23:25 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'S1_rebuild_or_reorganize', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d master -Q "EXECUTE dbo.IndexOptimize @Databases = ''USER_DATABASES'',@FragmentationLow = NULL,@FragmentationMedium = ''INDEX_REORGANIZE,INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE'',@FragmentationHigh = ''INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE'',@FragmentationLevel1 = 5,@FragmentationLevel2 = 30,@TimeLimit = 3600" -b', 
		@flags=32
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'S1_Rebuild_or_Reorganzie_schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151027, 
		@active_end_date=99991231, 
		@active_start_time=30000, 
		@active_end_time=235959, 
		@schedule_uid=N'427c0b4e-78a4-45b5-be05-c450d52b4330'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [J6_Update_stats]    Script Date: 3/20/2017 11:23:25 AM ******/
BEGIN TRANSACTION
DECLARE @jobId_temp binary(16)
SELECT @jobId_temp = job_id FROM msdb.dbo.sysjobs WHERE (name = N'J6_Update_stats')
IF (@jobId_temp IS NOT NULL)
BEGIN
    EXEC msdb.dbo.sp_delete_job @jobId_temp
END
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 3/20/2017 11:23:25 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'J6_Update_stats', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=3, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job updates stats for all databases', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [S1_update_stats]    Script Date: 3/20/2017 11:23:25 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'S1_update_stats', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d master -Q "EXECUTE dbo.IndexOptimize @Databases = ''USER_DATABASES'',@FragmentationLow = NULL,@FragmentationMedium = NULL,@FragmentationHigh = NULL,@UpdateStatistics = ''ALL'',@OnlyModifiedStatistics = ''Y''" -b', 
		@flags=32
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'S1_Update_stats', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151019, 
		@active_end_date=99991231, 
		@active_start_time=40000, 
		@active_end_time=235959, 
		@schedule_uid=N'45d83b82-2427-4a87-b6fb-d6e1388d5e1d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [J7_History_Cleanup]    Script Date: 3/20/2017 11:23:25 AM ******/
BEGIN TRANSACTION
DECLARE @jobId_temp binary(16)
SELECT @jobId_temp = job_id FROM msdb.dbo.sysjobs WHERE (name = N'J7_History_Cleanup')
IF (@jobId_temp IS NOT NULL)
BEGIN
    EXEC msdb.dbo.sp_delete_job @jobId_temp
END
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 3/20/2017 11:23:25 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'J7_History_Cleanup', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=3, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job will delete older backups (> 4 weeks)', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 3/20/2017 11:23:25 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'BEGIN TRY
declare @dt datetime = dateadd(wk,-4,getdate()),
@backuploc varchar(256)=[dbo].[fn_SQLServerBackupDir]()  
exec msdb.dbo.sp_delete_backuphistory @dt
EXECUTE master.dbo.xp_delete_file 0,@backuploc,N''.bak'',@dt
END TRY
BEGIN CATCH
    SELECT 
        ERROR_NUMBER() AS ErrorNumber
       ,ERROR_MESSAGE() AS ErrorMessage;
END CATCH
', 
		@database_name=N'master', 
		@flags=4
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'S1_History_Cleanup_schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151020, 
		@active_end_date=99991231, 
		@active_start_time=50000, 
		@active_end_time=235959, 
		@schedule_uid=N'be8e50bb-004d-45ff-9f9e-a7162e231c9a'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [J8_Purge_process]    Script Date: 3/20/2017 11:23:25 AM ******/
BEGIN TRANSACTION
DECLARE @jobId_temp binary(16)
SELECT @jobId_temp = job_id FROM msdb.dbo.sysjobs WHERE (name = N'J8_Purge_process')
IF (@jobId_temp IS NOT NULL)
BEGIN
    EXEC msdb.dbo.sp_delete_job @jobId_temp
END
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 3/20/2017 11:23:25 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'J8_Purge_process', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Identifies tables for logging and cleanup records older than 90 days', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'S1_Purge_process', 
		@enabled=1, 
		@freq_type=16, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151021, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'112f205b-48c2-4cb2-af0c-2d54d73b8811'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO
