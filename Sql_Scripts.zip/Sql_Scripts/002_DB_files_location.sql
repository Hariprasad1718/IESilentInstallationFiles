use master 
select  name,type_desc,physical_name,state_desc from sys.master_files 