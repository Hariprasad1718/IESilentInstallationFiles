-- SET INSTANCE DEV/TEST
DECLARE @Instance AS VARCHAR(20) = '';
DECLARE @IsNewEnvironment AS CHAR(1) = 'N';
DECLARE @IsRecreateDBAppUsrRole AS CHAR(1) = 'Y';
DECLARE @SQLString AS VARCHAR(MAX) = '';

IF (@Instance = '')
BEGIN
    PRINT 'Set @Instance as either DEV or TEST';
END;

IF (@IsNewEnvironment = '')
BEGIN
    PRINT 'Set @IsNewEnvironment as Y/N';
END;

IF (@IsRecreateDBAppUsrRole = '')
BEGIN
    PRINT 'Set @IsRecreateDBAppUsrRole as Y/N';
END;

IF (
       DB_NAME() IN ( 'KYHBE', 'KYHBEArchive', 'Logging', 'SelfService', 'ConversionIE', 'ConversionIE_Archive', 'OHAMCI', 'OHAMCIViews' )
       AND @Instance IN ( 'DEV', 'TEST' )
       AND @IsNewEnvironment IN ( 'Y', 'N' )
       AND @IsRecreateDBAppUsrRole IN ( 'Y', 'N' )
   )
BEGIN
	--CREATE EXECUTE ROLE
    IF (ISNULL([sys].[fn_hadr_is_primary_replica](DB_NAME()), 1) = 1)
    BEGIN
    --    IF (
    --           EXISTS
    --    (
    --        SELECT 1
    --        FROM [sys].[database_principals]
    --        WHERE [type_desc] = 'DATABASE_ROLE'
    --              AND [name] = 'DBExecuteRole'
    --    )
    --           AND @IsRecreateDBAppUsrRole = 'Y'
    --       )
    --    BEGIN
    --        SELECT @SQLString = @SQLString + '
    --ALTER ROLE '                + QUOTENAME('DBExecuteRole') + ' DROP MEMBER ' + QUOTENAME(members.[name]) + ';'
    --        FROM sys.database_role_members AS rolemembers
    --            JOIN sys.database_principals AS roles
    --                ON roles.[principal_id] = rolemembers.[role_principal_id]
    --            JOIN sys.database_principals AS members
    --                ON members.[principal_id] = rolemembers.[member_principal_id]
    --        WHERE roles.[name] = 'DBExecuteRole';

    --        EXEC (@SQLString);

    --        DROP ROLE [DBExecuteRole];
    --    END;

        IF NOT EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'DATABASE_ROLE'
                  AND [name] = 'DBExecuteRole'
        )
        BEGIN
            CREATE ROLE [DBExecuteRole];
        END;

        -- GRANT CONNECT TO ROLE
        GRANT CONNECT TO [DBExecuteRole];

        -- GRANT EXECUTE TO ROLE
        GRANT EXECUTE TO [DBExecuteRole];
    END;

    --CREATE APP ROLE
    IF (ISNULL([sys].[fn_hadr_is_primary_replica](DB_NAME()), 1) = 1)
    BEGIN
        IF (
               EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'DATABASE_ROLE'
                  AND [name] = 'DBAppUsrRole'
        )
               AND @IsRecreateDBAppUsrRole = 'Y'
           )
        BEGIN
            SELECT @SQLString = @SQLString + '
    ALTER ROLE '                + QUOTENAME('DBAppUsrRole') + ' DROP MEMBER ' + QUOTENAME(members.[name]) + ';'
            FROM sys.database_role_members AS rolemembers
                JOIN sys.database_principals AS roles
                    ON roles.[principal_id] = rolemembers.[role_principal_id]
                JOIN sys.database_principals AS members
                    ON members.[principal_id] = rolemembers.[member_principal_id]
            WHERE roles.[name] = 'DBAppUsrRole';

            EXEC (@SQLString);

            DROP ROLE [DBAppUsrRole];
        END;

        IF NOT EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'DATABASE_ROLE'
                  AND [name] = 'DBAppUsrRole'
        )
        BEGIN
            CREATE ROLE [DBAppUsrRole];
        END;

        -- GRANT CONNECT TO ROLE
        GRANT CONNECT TO [DBAppUsrRole];

        -- GRANT DATAREADER TO ROLE
        EXEC sp_addrolemember 'db_datareader', 'DBAppUsrRole';

        -- GRANT DATAWRITER TO ROLE
        EXEC sp_addrolemember 'db_datawriter', 'DBAppUsrRole';

        -- GRANT EXECUTE TO ROLE
		EXEC sp_addrolemember 'DBExecuteRole', 'DBAppUsrRole';

        -- GRANT VIEW DEFINITION TO ROLE
        GRANT VIEW DEFINITION TO [DBAppUsrRole];

        -- GRANT SHOWPLAN TO ROLE
        GRANT SHOWPLAN TO [DBAppUsrRole];

        --DENY INSERT TO KYHBE DAY0 RT TABLES
        IF (DB_NAME() = 'KYHBE')
        BEGIN

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Batchjob' AND TABLE_NAME = 'Jobdetail'))
					    DENY INSERT,DELETE,UPDATE ON [Batchjob].[Jobdetail] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Batchjob' AND TABLE_NAME = 'Jobstep'))
					    DENY INSERT,DELETE,UPDATE ON [Batchjob].[Jobstep] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Batchjob' AND TABLE_NAME = 'Jobsubstep'))
					    DENY INSERT,DELETE,UPDATE ON [Batchjob].[Jobsubstep] TO [DBAppUsrRole];
		
		--IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Benefitmanagement' AND TABLE_NAME = 'Bmcontroldate'))
		--			    DENY INSERT,DELETE,UPDATE ON [Benefitmanagement].[Bmcontroldate] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Benefitmanagement' AND TABLE_NAME = 'Bminterfacemetadata'))
					    DENY INSERT,DELETE,UPDATE ON [Benefitmanagement].[Bminterfacemetadata] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Benefitmanagement' AND TABLE_NAME = 'Filecontrolnumber'))
					    DENY INSERT,DELETE,UPDATE ON [Benefitmanagement].[Filecontrolnumber] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'Batchreportreference'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[Batchreportreference] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'BundlingCriteria'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[BundlingCriteria] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'Correspondencemapping'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[Correspondencemapping] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'Correspondencetemplate'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[Correspondencetemplate] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'CorrespondenceTemplateBody'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[CorrespondenceTemplateBody] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'Correspondencetemplateparameters'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[Correspondencetemplateparameters] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'Hpexstreamconfigdata'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[Hpexstreamconfigdata] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'Manualfield'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[Manualfield] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'Purgepolicy'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[Purgepolicy] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'Scheduledstoredprocedures'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[Scheduledstoredprocedures] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Datacollection' AND TABLE_NAME = 'Casedatachangeentitytypedisplayname'))
					    DENY INSERT,DELETE,UPDATE ON [Datacollection].[Casedatachangeentitytypedisplayname] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Datacollection' AND TABLE_NAME = 'Cdcprocessingconfiguration'))
					    DENY INSERT,DELETE,UPDATE ON [Datacollection].[Cdcprocessingconfiguration] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'DataCollection' AND TABLE_NAME = 'RACOrRenewalConfig'))
					    DENY INSERT,DELETE,UPDATE ON [DataCollection].[RACOrRenewalConfig] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'DataCollection' AND TABLE_NAME = 'VerificationCodeValidation'))
					    DENY INSERT,DELETE,UPDATE ON [DataCollection].[VerificationCodeValidation] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Eligibilitydetermination' AND TABLE_NAME = 'Edbcbatchsettings'))
					    DENY INSERT,DELETE,UPDATE ON [Eligibilitydetermination].[Edbcbatchsettings] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'EligibilityDetermination' AND TABLE_NAME = 'EdbcMUTriggerPermission'))
					    DENY INSERT,DELETE,UPDATE ON [EligibilityDetermination].[EdbcMUTriggerPermission] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Eligibilitydetermination' AND TABLE_NAME = 'Edprogramcategory'))
					    DENY INSERT,DELETE,UPDATE ON [Eligibilitydetermination].[Edprogramcategory] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Eligibilitydetermination' AND TABLE_NAME = 'Edrficatalogue'))
					    DENY INSERT,DELETE,UPDATE ON [Eligibilitydetermination].[Edrficatalogue] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Form1095b' AND TABLE_NAME = 'Jobdetail'))
					    DENY INSERT,DELETE,UPDATE ON [Form1095b].[Jobdetail] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Form1095b' AND TABLE_NAME = 'Jobstep'))
					    DENY INSERT,DELETE,UPDATE ON [Form1095b].[Jobstep] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Form1095b' AND TABLE_NAME = 'Referencemasterdata'))
					    DENY INSERT,DELETE,UPDATE ON [Form1095b].[Referencemasterdata] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Form1095b' AND TABLE_NAME = 'Roleassociation'))
					    DENY INSERT,DELETE,UPDATE ON [Form1095b].[Roleassociation] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Form1095b' AND TABLE_NAME = 'Rolemaster'))
					    DENY INSERT,DELETE,UPDATE ON [Form1095b].[Rolemaster] TO [DBAppUsrRole];
		
		--IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Accesslevel'))
		--			    DENY INSERT,DELETE,UPDATE ON [Framework].[Accesslevel] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Activityconfiguration'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Activityconfiguration] TO [DBAppUsrRole];
		
		--IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Businessfunction'))
		--			    DENY INSERT,DELETE,UPDATE ON [Framework].[Businessfunction] TO [DBAppUsrRole];
		
		--IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Businessfunctionsecurityobjectassociation'))
		--			    DENY INSERT,DELETE,UPDATE ON [Framework].[Businessfunctionsecurityobjectassociation] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Businesslogic'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Businesslogic] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Configtable'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Configtable] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Datachangeevent'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Datachangeevent] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Datachangeeventactionmethod'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Datachangeeventactionmethod] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Datachangeeventadditionalcontextvaluesprovider'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Datachangeeventadditionalcontextvaluesprovider] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Datachangeeventcontextvaluestocapture'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Datachangeeventcontextvaluestocapture] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Datachangeevententityfilter'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Datachangeevententityfilter] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'DataChangeEventIgnoreColumn'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[DataChangeEventIgnoreColumn] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Eligibilityverificationchecklistlandingscreen'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Eligibilityverificationchecklistlandingscreen] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Linkedtaskscreenmapper'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Linkedtaskscreenmapper] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Navigatoractiondrivenproperty'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Navigatoractiondrivenproperty] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Processconfiguration'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Processconfiguration] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Propertybusinesslogicsource'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Propertybusinesslogicsource] TO [DBAppUsrRole];
		
		--IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Roleassignmentassociation'))
		--			    DENY INSERT,DELETE,UPDATE ON [Framework].[Roleassignmentassociation] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screenadditionalattributes'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screenadditionalattributes] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screenbuilderdataelement'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screenbuilderdataelement] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screenbuilderdataelementprogrammap'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screenbuilderdataelementprogrammap] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screenbuilderpage'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screenbuilderpage] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screenbuilderprogram'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screenbuilderprogram] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screenbuildersection'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screenbuildersection] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screenbusinesslogic'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screenbusinesslogic] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screenbusinesslogicsource'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screenbusinesslogicsource] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screendataassociation'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screendataassociation] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'ScreenDataProgramAssociation'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[ScreenDataProgramAssociation] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screendefault'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screendefault] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screendriverdefault'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screendriverdefault] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screengroupdefault'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screengroupdefault] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Screenpropertyassociation'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Screenpropertyassociation] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'ScreenPropertyProgramAssociation'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[ScreenPropertyProgramAssociation] TO [DBAppUsrRole];
		
		--IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Securityobject'))
		--			    DENY INSERT,DELETE,UPDATE ON [Framework].[Securityobject] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Securityobjecttype'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Securityobjecttype] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Securityrole'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Securityrole] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Sequenceconfiguration'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Sequenceconfiguration] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Sourceapplication'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Sourceapplication] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Sspwebhelpmap'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Sspwebhelpmap] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Taskconfiguration'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Taskconfiguration] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'Webhelpmap'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[Webhelpmap] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Interface' AND TABLE_NAME = 'FFMConfiguration'))
					    DENY INSERT,DELETE,UPDATE ON [Interface].[FFMConfiguration] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Interface' AND TABLE_NAME = 'Interfacedetails'))
					    DENY INSERT,DELETE,UPDATE ON [Interface].[Interfacedetails] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Interface' AND TABLE_NAME = 'Interfacetriggerconfiguration'))
					    DENY INSERT,DELETE,UPDATE ON [Interface].[Interfacetriggerconfiguration] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Interface' AND TABLE_NAME = 'Mmistoamapping'))
					    DENY INSERT,DELETE,UPDATE ON [Interface].[Mmistoamapping] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Interface' AND TABLE_NAME = 'Outboundconfiguration'))
					    DENY INSERT,DELETE,UPDATE ON [Interface].[Outboundconfiguration] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Interface' AND TABLE_NAME = 'SendATInterfaceControl'))
					    DENY INSERT,DELETE,UPDATE ON [Interface].[SendATInterfaceControl] TO [DBAppUsrRole];
		
		--IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Manageofficeresource' AND TABLE_NAME = 'Securityroleannoumcementroleassociation'))
		--			    DENY INSERT,DELETE,UPDATE ON [Manageofficeresource].[Securityroleannoumcementroleassociation] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Referencedata' AND TABLE_NAME = 'Referencetableadditionalattributename'))
					    DENY INSERT,DELETE,UPDATE ON [Referencedata].[Referencetableadditionalattributename] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Referencedata' AND TABLE_NAME = 'Referencetableadditionalattributevalue'))
					    DENY INSERT,DELETE,UPDATE ON [Referencedata].[Referencetableadditionalattributevalue] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Referencedata' AND TABLE_NAME = 'Referencetablename'))
					    DENY INSERT,DELETE,UPDATE ON [Referencedata].[Referencetablename] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Referencedata' AND TABLE_NAME = 'Referencetablevalue'))
					    DENY INSERT,DELETE,UPDATE ON [Referencedata].[Referencetablevalue] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Referencedata' AND TABLE_NAME = 'Reportlisting'))
					    DENY INSERT,DELETE,UPDATE ON [Referencedata].[Reportlisting] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Referencedata' AND TABLE_NAME = 'Reportparameter'))
					    DENY INSERT,DELETE,UPDATE ON [Referencedata].[Reportparameter] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Reports' AND TABLE_NAME = 'Calendar'))
					    DENY INSERT,DELETE,UPDATE ON [Reports].[Calendar] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Taskmanagement' AND TABLE_NAME = 'Tasklandingscreen'))
					    DENY INSERT,DELETE,UPDATE ON [Taskmanagement].[Tasklandingscreen] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Interface' AND TABLE_NAME = 'MMISAgencyCodeCaseDescriptorMapping'))
					    DENY INSERT,DELETE,UPDATE ON [Interface].[MMISAgencyCodeCaseDescriptorMapping] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'FunctionParameterMaster'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[FunctionParameterMaster] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'FunctionParameterAssociation'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[FunctionParameterAssociation] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'RulesheetMaster'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[RulesheetMaster] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'ConditionMaster'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[ConditionMaster] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'RulesMaster'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[RulesMaster] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'TaskRulesheetMapping'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[TaskRulesheetMapping] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'RuleConditionMapping'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[RuleConditionMapping] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'TMTaskConfigPrimaryAttribute'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[TMTaskConfigPrimaryAttribute] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'TMPrimaryAttributeAssociation'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[TMPrimaryAttributeAssociation] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'TMDueDateMaster'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[TMDueDateMaster] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'TaskTypeDueDateMapping'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[TaskTypeDueDateMapping] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'TMSecondaryAssociationMaster'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[TMSecondaryAssociationMaster] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'TaskManagement' AND TABLE_NAME = 'TMSecondaryAssociationMapping'))
					    DENY INSERT,DELETE,UPDATE ON [TaskManagement].[TMSecondaryAssociationMapping] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'ReprintPackageFileMapping'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[ReprintPackageFileMapping] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Conversion' AND TABLE_NAME = 'BranchOffice'))
					    DENY INSERT,DELETE,UPDATE ON [Conversion].[BranchOffice] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'DataDereferencingHelper'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[DataDereferencingHelper] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'ScheduledDIValidationProcedure'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[ScheduledDIValidationProcedure] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'RulesheetMaster'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[RulesheetMaster] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'RulesMaster'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[RulesMaster] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'ConditionMaster'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[ConditionMaster] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'FunctionParameterMaster'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[FunctionParameterMaster] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'FunctionParameterAssociation'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[FunctionParameterAssociation] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'RuleConditionMapping'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[RuleConditionMapping] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'TaskRulesheetMapping'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[TaskRulesheetMapping] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'EntryCriteria'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[EntryCriteria] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'ManageOfficeResource' AND TABLE_NAME = 'RegionCountyAssociation'))
					    DENY INSERT,DELETE,UPDATE ON [ManageOfficeResource].[RegionCountyAssociation] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'DataCollection' AND TABLE_NAME = 'EducationConfiguration'))
					    DENY INSERT,DELETE,UPDATE ON [DataCollection].[EducationConfiguration] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'ManageOfficeResource' AND TABLE_NAME = 'CaseOfficeZipCode'))
					    DENY INSERT,DELETE,UPDATE ON [ManageOfficeResource].[CaseOfficeZipCode] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Interface' AND TABLE_NAME = 'VLPNextStep'))
					    DENY INSERT,DELETE,UPDATE ON [Interface].[VLPNextStep] TO [DBAppUsrRole];
		
		--IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'TimeTravelUser'))
		--			    DENY INSERT,DELETE,UPDATE ON [Framework].[TimeTravelUser] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'ValidationProcedureMapping'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[ValidationProcedureMapping] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Reports' AND TABLE_NAME = 'ReportsProcessParameters'))
					    DENY INSERT,DELETE,UPDATE ON [Reports].[ReportsProcessParameters] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'EligibilityDetermination' AND TABLE_NAME = 'EDBCDispositionValidation'))
					    DENY INSERT,DELETE,UPDATE ON [EligibilityDetermination].[EDBCDispositionValidation] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Interface' AND TABLE_NAME = 'InterfaceKeyConfiguration'))
					    DENY INSERT,DELETE,UPDATE ON [Interface].[InterfaceKeyConfiguration] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'CorrespondenceQCRTemplate'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[CorrespondenceQCRTemplate] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'DataChangeEventEffectiveEntityConfiguration'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[DataChangeEventEffectiveEntityConfiguration] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Correspondence' AND TABLE_NAME = 'CorrespondenceQCRCategory'))
					    DENY INSERT,DELETE,UPDATE ON [Correspondence].[CorrespondenceQCRCategory] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'EligibilityDetermination' AND TABLE_NAME = 'ConversionBenefitMatchConfig'))
					    DENY INSERT,DELETE,UPDATE ON [EligibilityDetermination].[ConversionBenefitMatchConfig] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'UserActivityConfiguration'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[UserActivityConfiguration] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Sebtc' AND TABLE_NAME = 'SebtcSchoolYearEDM'))
					    DENY INSERT,DELETE,UPDATE ON [Sebtc].[SebtcSchoolYearEDM] TO [DBAppUsrRole];
        END;

        --DENY INSERT TO SelfService DAY0 RT TABLES
        IF (DB_NAME() = 'SelfService')
        BEGIN
            

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'FAQCategory'))
					    DENY INSERT,DELETE,UPDATE ON [dbo].[FAQCategory] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'FAQQuestionAnswer'))
					    DENY INSERT,DELETE,UPDATE ON [dbo].[FAQQuestionAnswer] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'InterfaceControl'))
					    DENY INSERT,DELETE,UPDATE ON [dbo].[InterfaceControl] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'RoleProgramAccess'))
					    DENY INSERT,DELETE,UPDATE ON [dbo].[RoleProgramAccess] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'FFM' AND TABLE_NAME = 'FFMApplicationScoreCriteria'))
					    DENY INSERT,DELETE,UPDATE ON [FFM].[FFMApplicationScoreCriteria] TO [DBAppUsrRole];
		
		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'FFM' AND TABLE_NAME = 'FFMReferenceTable'))
					    DENY INSERT,DELETE,UPDATE ON [FFM].[FFMReferenceTable] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'EntryCriteria'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[EntryCriteria] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'FunctionParameterMaster'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[EntryCriteria] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'FunctionParameterAssociation'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[EntryCriteria] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'RuleConditionMapping'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[EntryCriteria] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'RulesMaster'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[EntryCriteria] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'RulesheetMaster'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[EntryCriteria] TO [DBAppUsrRole];

		IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Framework' AND TABLE_NAME = 'ConditionMaster'))
					    DENY INSERT,DELETE,UPDATE ON [Framework].[EntryCriteria] TO [DBAppUsrRole];

        END;

        --DENY INSERT TO Logging DAY0 RT TABLES
        IF (DB_NAME() = 'Logging')
        BEGIN
            IF (EXISTS
            (
                SELECT 1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'ReferenceData'
                      AND TABLE_NAME = 'Referencetableadditionalattributename'
            )
               )
                DENY INSERT,
                     DELETE,
                     UPDATE
                ON [ReferenceData].[ReferenceTableAdditionalAttributeName]
                TO  [DBAppUsrRole];

            IF (EXISTS
            (
                SELECT 1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'ReferenceData'
                      AND TABLE_NAME = 'Referencetableadditionalattributevalue'
            )
               )
                DENY INSERT,
                     DELETE,
                     UPDATE
                ON [ReferenceData].[ReferenceTableAdditionalAttributeValue]
                TO  [DBAppUsrRole];

            IF (EXISTS
            (
                SELECT 1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'ReferenceData'
                      AND TABLE_NAME = 'Referencetablename'
            )
               )
                DENY INSERT,
                     DELETE,
                     UPDATE
                ON [ReferenceData].[ReferenceTableName]
                TO  [DBAppUsrRole];

            IF (EXISTS
            (
                SELECT 1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'ReferenceData'
                      AND TABLE_NAME = 'Referencetablevalue'
            )
               )
                DENY INSERT,
                     DELETE,
                     UPDATE
                ON [ReferenceData].[ReferenceTableValue]
                TO  [DBAppUsrRole];

            IF (EXISTS
            (
                SELECT 1
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = 'dbo'
                      AND TABLE_NAME = 'LogPurgePolicy'
            )
               )
                DENY INSERT, DELETE, UPDATE ON [dbo].[LogPurgePolicy] TO [DBAppUsrRole];
        END;

		 IF (DB_NAME() = 'ConversionIE')
		 BEGIN
			DENY INSERT, DELETE, UPDATE ON [dbo].[ConversionCrossReferenceValue] TO [DBAppUsrRole];
			--DENY INSERT, DELETE, UPDATE ON [dbo].[ConversionProcessParameters] TO [DBAppUsrRole];
			--DENY INSERT, DELETE, UPDATE ON [dbo].[DUJobSequencing] TO [DBAppUsrRole];
			DENY INSERT, DELETE, UPDATE ON [dbo].[EntityProgramPrecedenceMaster] TO [DBAppUsrRole];
			DENY INSERT, DELETE, UPDATE ON [dbo].[ErrorMasterTable] TO [DBAppUsrRole];
			DENY INSERT, DELETE, UPDATE ON [dbo].[FileLandingNMTOAHierarchy] TO [DBAppUsrRole];
			DENY INSERT, DELETE, UPDATE ON [dbo].[FIPSCounty] TO [DBAppUsrRole];
			DENY INSERT, DELETE, UPDATE ON [dbo].[MasterFileNames] TO [DBAppUsrRole];
			DENY INSERT, DELETE, UPDATE ON [dbo].[OverlapToas] TO [DBAppUsrRole];
		 END
    END;

	--CREATE REPORT ROLE
    IF (ISNULL([sys].[fn_hadr_is_primary_replica](DB_NAME()), 1) = 1)
    BEGIN
        IF (
               EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'DATABASE_ROLE'
                  AND [name] = 'DBReportUsrRole'
        )
               AND @IsRecreateDBAppUsrRole = 'Y'
           )
        BEGIN
            SELECT @SQLString = @SQLString + '
    ALTER ROLE '                + QUOTENAME('DBReportUsrRole') + ' DROP MEMBER ' + QUOTENAME(members.[name]) + ';'
            FROM sys.database_role_members AS rolemembers
                JOIN sys.database_principals AS roles
                    ON roles.[principal_id] = rolemembers.[role_principal_id]
                JOIN sys.database_principals AS members
                    ON members.[principal_id] = rolemembers.[member_principal_id]
            WHERE roles.[name] = 'DBReportUsrRole';

            EXEC (@SQLString);

            DROP ROLE [DBReportUsrRole];
        END;

        IF NOT EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'DATABASE_ROLE'
                  AND [name] = 'DBReportUsrRole'
        )
        BEGIN
            CREATE ROLE [DBReportUsrRole];
        END;

        -- GRANT CONNECT TO ROLE
        GRANT CONNECT TO [DBReportUsrRole];

        -- GRANT DATAREADER TO ROLE
        EXEC sp_addrolemember 'db_datareader', 'DBReportUsrRole';

        -- GRANT EXECUTE TO ROLE
		EXEC sp_addrolemember 'DBExecuteRole', 'DBReportUsrRole';

        -- GRANT VIEW DEFINITION TO ROLE
        GRANT VIEW DEFINITION TO [DBReportUsrRole];

        --DENY INSERT TO KYHBE DAY0 RT TABLES
        IF (DB_NAME() = 'KYHBE')
        BEGIN
			IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = 'Reports'))
				GRANT INSERT,DELETE,UPDATE ON SCHEMA::[Reports] TO [DBReportUsrRole];
				
			IF (EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Reports' AND TABLE_NAME = 'Calendar'))
				DENY INSERT,DELETE,UPDATE ON [Reports].[Calendar] TO [DBReportUsrRole];
		END
    END;

	--CREATE ALTER ROLE
    IF (ISNULL([sys].[fn_hadr_is_primary_replica](DB_NAME()), 1) = 1)
    BEGIN
        IF (
               EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'DATABASE_ROLE'
                  AND [name] = 'DBAlterRole'
        )
               AND @IsRecreateDBAppUsrRole = 'Y'
           )
        BEGIN
            SELECT @SQLString = @SQLString + '
    ALTER ROLE '                + QUOTENAME('DBAlterRole') + ' DROP MEMBER ' + QUOTENAME(members.[name]) + ';'
            FROM sys.database_role_members AS rolemembers
                JOIN sys.database_principals AS roles
                    ON roles.[principal_id] = rolemembers.[role_principal_id]
                JOIN sys.database_principals AS members
                    ON members.[principal_id] = rolemembers.[member_principal_id]
            WHERE roles.[name] = 'DBAlterRole';

            EXEC (@SQLString);

            DROP ROLE [DBAlterRole];
        END;

        IF NOT EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'DATABASE_ROLE'
                  AND [name] = 'DBAlterRole'
        )
        BEGIN
            CREATE ROLE [DBAlterRole];
        END;

        -- GRANT CONNECT TO ROLE
        GRANT CONNECT TO [DBAlterRole];

        BEGIN
                SELECT @SQLString
                    = STUFF(
                      (
                          SELECT ' ' + 'GRANT ALTER ON [' + [TABLE_SCHEMA] + '].[' + [TABLE_NAME]
                                 + '] TO [DBAlterRole];'
                          FROM [INFORMATION_SCHEMA].[TABLES]
                          WHERE [TABLE_NAME] LIKE '%Staging%'
                                AND [TABLE_TYPE] = 'BASE TABLE'
                          FOR XML PATH('')
                      ),
                      1,
                      1,
                      ''
                           );

                EXECUTE (@SQLString);
            END;
    END;

    --DROP LOGINS
    IF (@IsNewEnvironment = 'Y')
    BEGIN
        -- Login: IDBA
        IF EXISTS
        (
            SELECT 1
            FROM [master].[sys].[server_principals]
            WHERE [name] = 'IDBA'
        )
        BEGIN
            DROP LOGIN [IDBA];
        END;

        -- Login: _developer
        IF EXISTS
        (
            SELECT 1
            FROM [master].[sys].[server_principals]
            WHERE [name] = '_developer'
        )
        BEGIN
            DROP LOGIN [_developer];
        END;

        -- Login: _tester
        IF EXISTS
        (
            SELECT 1
            FROM [master].[sys].[server_principals]
            WHERE [name] = '_tester'
        )
        BEGIN
            DROP LOGIN [_tester];
        END;

        -- Login: REPORTUSER
        IF EXISTS
        (
            SELECT 1
            FROM [master].[sys].[server_principals]
            WHERE [name] = 'REPORTUSER'
        )
        BEGIN
            DROP LOGIN [REPORTUSER];
        END;

        -- Login: ohamci
        IF (
               EXISTS
        (
            SELECT 1
            FROM [master].[sys].[server_principals]
            WHERE [name] = 'ohamci'
        )
               AND DB_NAME() = 'OHAMCI'
           )
        BEGIN
            DROP LOGIN [ohamci];
        END;

        -- Login: svc_sqlmciview
        IF (
               EXISTS
        (
            SELECT 1
            FROM [master].[sys].[server_principals]
            WHERE [name] = 'svc_sqlmciview'
        )
               AND DB_NAME() = 'OHAMCIViews'
           )
        BEGIN
            DROP LOGIN [svc_sqlmciview];
        END;
    END;

    --CREATE LOGINS
    BEGIN
        IF (@Instance = 'DEV')
        BEGIN
            -- Login: ONE\svc_dbappuser_ied
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_dbappuser_ied'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_dbappuser_ied] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

			 -- Login: ONE\svc_db_ttuser1_ied
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_db_ttuser1_ied'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_db_ttuser1_ied] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

			 -- Login: ONE\svc_db_ttuser2_ied
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_db_ttuser2_ied'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_db_ttuser2_ied] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

			 -- Login: ONE\svc_db_ttuser3_ied
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_db_ttuser3_ied'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_db_ttuser3_ied] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

			-- Login: ONE\svc_db_ttuser4_ied
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_db_ttuser4_ied'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_db_ttuser4_ied] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

			-- Login: ONE\svc_db_ttuser5_ied
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_db_ttuser5_ied'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_db_ttuser5_ied] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_dbat_ied_ad
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_dbat_ied_ad'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_dbat_ied_ad] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_bt_inp_ad_ied
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_bt_inp_ad_ied'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_bt_inp_ad_ied] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

			-- Login: ONE\svc_sqlreport_ied
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_sqlreport_ied'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_sqlreport_ied] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;
        END;

        IF (@Instance = 'TEST')
        BEGIN
            -- Login: ONE\svc_dbappuser_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_dbappuser_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_dbappuser_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_dbappuser1_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_dbappuser1_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_dbappuser1_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_dbappuser2_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_dbappuser2_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_dbappuser2_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_dbappuser3_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_dbappuser3_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_dbappuser3_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_dbappuser4_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_dbappuser4_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_dbappuser4_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_dbappuser5_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_dbappuser5_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_dbappuser5_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_db_ttuser1_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_db_ttuser1_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_db_ttuser1_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_db_ttuser2_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_db_ttuser2_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_db_ttuser2_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_db_ttuser3_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_db_ttuser3_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_db_ttuser3_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_db_ttuser4_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_db_ttuser4_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_db_ttuser4_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_db_ttuser5_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_db_ttuser5_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_db_ttuser5_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_dbat_iet_ad
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_dbat_iet_ad'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_dbat_iet_ad] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

            -- Login: ONE\svc_bt_inp_ad_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_bt_inp_ad_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_bt_inp_ad_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;

			 -- Login: ONE\svc_sqlreport_iet
            IF NOT EXISTS
            (
                SELECT 1
                FROM [master].[sys].[server_principals]
                WHERE [name] = 'ONE\svc_sqlreport_iet'
            )
            BEGIN
                CREATE LOGIN [ONE\svc_sqlreport_iet] FROM WINDOWS
                WITH DEFAULT_DATABASE = [master];
            END;
        END;

        -- Login: IDBA
        IF NOT EXISTS
        (
            SELECT 1
            FROM [master].[sys].[server_principals]
            WHERE [name] = 'IDBA'
        )
        BEGIN
            CREATE LOGIN [IDBA]
            WITH PASSWORD = 0x0200EF122CF7CA0797DB9A31E288ED51687D91B39B9338197E7BFECB74B549A37D7CC7F0111AAD7D8D46350ED710B6E7F8C4E7F8922AB9E17EAD6268A983FB59EFCE81CFE89B HASHED,
                 SID = 0x802D67358F59D44CA39AE4B576FFEFD5,
                 DEFAULT_DATABASE = [master],
                 CHECK_POLICY = OFF,
                 CHECK_EXPIRATION = OFF;
        END;

        -- Login: _developer
        IF NOT EXISTS
        (
            SELECT 1
            FROM [master].[sys].[server_principals]
            WHERE [name] = '_developer'
        )
        BEGIN
            CREATE LOGIN [_developer]
            WITH PASSWORD = 0x0200DAF3A3658919071DFD8ACAAE83257EF9F1FDF5648F23F70F6013FF56168583AD4096380AEE81ABD013D7F13730DB887F5AB6371F1675AF865063C3D2535975B706364635 HASHED,
                 SID = 0xF8B748521BEDB148B4DD6B70EEA53115,
                 DEFAULT_DATABASE = [master],
                 CHECK_POLICY = OFF,
                 CHECK_EXPIRATION = OFF;
        END;

        -- Login: _tester
        IF NOT EXISTS
        (
            SELECT 1
            FROM [master].[sys].[server_principals]
            WHERE [name] = '_tester'
        )
        BEGIN
            CREATE LOGIN [_tester]
            WITH PASSWORD = 0x020001F826082B480CD50F987B183138C339A4CC1E9EEF353EA7563CD7EEAC1A582406B921BF3AC3675AB5A415D885B929D25D09DC86D43248FD5942FEAB14ED77F3D11761CB HASHED,
                 SID = 0x692511BC2E824F41A9D99F4D3FB762CA,
                 DEFAULT_DATABASE = [master],
                 CHECK_POLICY = OFF,
                 CHECK_EXPIRATION = OFF;
        END;

        -- Login: REPORTUSER
        IF NOT EXISTS
        (
            SELECT 1
            FROM [master].[sys].[server_principals]
            WHERE [name] = 'REPORTUSER'
        )
        BEGIN
            CREATE LOGIN [REPORTUSER]
            WITH PASSWORD = 0x0200E085106722B2A909DC6869C8C19CAA16844F7EDACF800E293E03BC50BE85916279D301564C9826EC601D3563DEEB0302363A2D65A886C374FCB8ADF96AEDB4586B0B8649 HASHED,
                 SID = 0x39EE73EBEFB03D469EBDAE562695CB53,
                 DEFAULT_DATABASE = [master],
                 CHECK_POLICY = OFF,
                 CHECK_EXPIRATION = OFF;
        END;

        -- Login: ohamci
        IF (
               NOT EXISTS
        (
            SELECT 1
            FROM [master].[sys].[server_principals]
            WHERE [name] = 'ohamci'
        )
               AND DB_NAME() = 'OHAMCI'
           )
        BEGIN
			IF(@Instance = 'DEV')
				BEGIN
					CREATE LOGIN [ohamci] WITH PASSWORD = 0x0200696AEE54D21A10730738FD016AFA48434141521DAFC848250A38F13F59A9495BE156211E25A5DB92F64AE99056E8CEA581D348F72386ADA8D4D21AA504219C8D67BABB87 HASHED, SID = 0x630ACDB3D5A3DC43947D2A213E116A85, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
				END
			ELSE IF(@Instance = 'TEST')
				BEGIN
					CREATE LOGIN [ohamci] WITH PASSWORD = 0x0200B7075465E2DC0F745B9DE107D22F17FE039340983DF1A288E73806447E84FC926BDAD2B30217D6B6A3E1EEC30628EE157F09BCD1C58A2D5E3A586EFB0D4EC820A595A4D2 HASHED, SID = 0x630ACDB3D5A3DC43947D2A213E116A85, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
				END
			ELSE 
				BEGIN
					CREATE LOGIN [ohamci] WITH PASSWORD = 0x0200696AEE54D21A10730738FD016AFA48434141521DAFC848250A38F13F59A9495BE156211E25A5DB92F64AE99056E8CEA581D348F72386ADA8D4D21AA504219C8D67BABB87 HASHED, SID = 0x630ACDB3D5A3DC43947D2A213E116A85, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
				END
        END;

        -- Login: svc_sqlmciview
        IF (
               NOT EXISTS
        (
            SELECT 1
            FROM [master].[sys].[server_principals]
            WHERE [name] = 'svc_sqlmciview'
        )
               AND DB_NAME() = 'OHAMCIViews'
           )
        BEGIN
            IF(@Instance = 'DEV')
				BEGIN
					CREATE LOGIN [svc_sqlmciview] WITH PASSWORD = 0x0200616919D9D4810CD7F2C31E84A53D0177191BDFA88439A5514FD9228C9A4035FAB61306C21C1496B5ACBBB78A57056F576786BD5B7D6727FFFAE87CAD7BF06A055DC1D016 HASHED, SID = 0xB100925BCEE8254E9FA062B7D7A63F6A, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
				END
			ELSE IF(@Instance = 'TEST')
				BEGIN
					CREATE LOGIN [svc_sqlmciview] WITH PASSWORD = 0x0200616919D9D4810CD7F2C31E84A53D0177191BDFA88439A5514FD9228C9A4035FAB61306C21C1496B5ACBBB78A57056F576786BD5B7D6727FFFAE87CAD7BF06A055DC1D016 HASHED, SID = 0xB100925BCEE8254E9FA062B7D7A63F6A, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
				END
			ELSE 
				BEGIN
					CREATE LOGIN [svc_sqlmciview] WITH PASSWORD = 0x0200616919D9D4810CD7F2C31E84A53D0177191BDFA88439A5514FD9228C9A4035FAB61306C21C1496B5ACBBB78A57056F576786BD5B7D6727FFFAE87CAD7BF06A055DC1D016 HASHED, SID = 0xB100925BCEE8254E9FA062B7D7A63F6A, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
				END
        END;
    END;

    --DROP DB USERS
    IF (
           (@IsNewEnvironment = 'Y' OR @IsRecreateDBAppUsrRole = 'Y')
           AND ISNULL([sys].[fn_hadr_is_primary_replica](DB_NAME()), 1) = 1
       )
    BEGIN
        IF EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'SQL_USER'
                  AND [name] = '_developer'
        )
        BEGIN
            DROP USER [_developer];
        END;

        IF EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'SQL_USER'
                  AND [name] = '_tester'
        )
        BEGIN
            DROP USER [_tester];
        END;

        IF EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'SQL_USER'
                  AND [name] = 'REPORTUSER'
        )
        BEGIN
            DROP USER [REPORTUSER];
        END;

        IF (
               EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'SQL_USER'
                  AND [name] = 'ohamci'
        )
               AND DB_NAME() = 'OHAMCI'
           )
        BEGIN
            DROP USER [ohamci];
        END;

        IF (
               EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'SQL_USER'
                  AND [name] = 'svc_sqlmciview'
        )
               AND DB_NAME() = 'OHAMCIViews'
           )
        BEGIN
            DROP USER [svc_sqlmciview];
        END;
    END;

    --CREATE DB USERS
    IF (ISNULL([sys].[fn_hadr_is_primary_replica](DB_NAME()), 1) = 1)
    BEGIN
        IF (@Instance = 'DEV')
        BEGIN
            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_dbappuser_ied'
            )
            BEGIN
                CREATE USER [ONE\svc_dbappuser_ied] FOR LOGIN [ONE\svc_dbappuser_ied]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

			IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_db_ttuser1_ied'
            )
            BEGIN
                CREATE USER [ONE\svc_db_ttuser1_ied] FOR LOGIN [ONE\svc_db_ttuser1_ied]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

			IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_db_ttuser2_ied'
            )
            BEGIN
                CREATE USER [ONE\svc_db_ttuser2_ied] FOR LOGIN [ONE\svc_db_ttuser2_ied]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

			IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_db_ttuser3_ied'
            )
            BEGIN
                CREATE USER [ONE\svc_db_ttuser3_ied] FOR LOGIN [ONE\svc_db_ttuser3_ied]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

			IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_db_ttuser4_ied'
            )
            BEGIN
                CREATE USER [ONE\svc_db_ttuser4_ied] FOR LOGIN [ONE\svc_db_ttuser4_ied]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

			IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_db_ttuser5_ied'
            )
            BEGIN
                CREATE USER [ONE\svc_db_ttuser5_ied] FOR LOGIN [ONE\svc_db_ttuser5_ied]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_dbat_ied_ad'
            )
            BEGIN
                CREATE USER [ONE\svc_dbat_ied_ad] FOR LOGIN [ONE\svc_dbat_ied_ad]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_bt_inp_ad_ied'
            )
            BEGIN
                CREATE USER [ONE\svc_bt_inp_ad_ied] FOR LOGIN [ONE\svc_bt_inp_ad_ied]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

			IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_sqlreport_ied'
            )
            BEGIN
                CREATE USER [ONE\svc_sqlreport_ied] FOR LOGIN [ONE\svc_sqlreport_ied]
                WITH DEFAULT_SCHEMA = [dbo];
            END;
        END;

        IF (@Instance = 'TEST')
        BEGIN
            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_dbappuser_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_dbappuser_iet] FOR LOGIN [ONE\svc_dbappuser_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_dbappuser1_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_dbappuser1_iet] FOR LOGIN [ONE\svc_dbappuser1_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_dbappuser2_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_dbappuser2_iet] FOR LOGIN [ONE\svc_dbappuser2_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_dbappuser3_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_dbappuser3_iet] FOR LOGIN [ONE\svc_dbappuser3_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_dbappuser4_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_dbappuser4_iet] FOR LOGIN [ONE\svc_dbappuser4_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_dbappuser5_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_dbappuser5_iet] FOR LOGIN [ONE\svc_dbappuser5_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_db_ttuser1_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_db_ttuser1_iet] FOR LOGIN [ONE\svc_db_ttuser1_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_db_ttuser2_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_db_ttuser2_iet] FOR LOGIN [ONE\svc_db_ttuser2_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_db_ttuser3_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_db_ttuser3_iet] FOR LOGIN [ONE\svc_db_ttuser3_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_db_ttuser4_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_db_ttuser4_iet] FOR LOGIN [ONE\svc_db_ttuser4_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_db_ttuser5_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_db_ttuser5_iet] FOR LOGIN [ONE\svc_db_ttuser5_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_dbat_iet_ad'
            )
            BEGIN
                CREATE USER [ONE\svc_dbat_iet_ad] FOR LOGIN [ONE\svc_dbat_iet_ad]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

            IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_bt_inp_ad_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_bt_inp_ad_iet] FOR LOGIN [ONE\svc_bt_inp_ad_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;

			IF NOT EXISTS
            (
                SELECT 1
                FROM [sys].[database_principals]
                WHERE [type_desc] = 'WINDOWS_USER'
                      AND [name] = 'ONE\svc_sqlreport_iet'
            )
            BEGIN
                CREATE USER [ONE\svc_sqlreport_iet] FOR LOGIN [ONE\svc_sqlreport_iet]
                WITH DEFAULT_SCHEMA = [dbo];
            END;
        END;

        IF NOT EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'SQL_USER'
                  AND [name] = '_developer'
        )
        BEGIN
            CREATE USER [_developer] FOR LOGIN [_developer]
            WITH DEFAULT_SCHEMA = [dbo];
        END;

        IF NOT EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'SQL_USER'
                  AND [name] = '_tester'
        )
        BEGIN
            CREATE USER [_tester] FOR LOGIN [_tester] WITH DEFAULT_SCHEMA = [dbo];
        END;

        IF NOT EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'SQL_USER'
                  AND [name] = 'REPORTUSER'
        )
        BEGIN
            CREATE USER [REPORTUSER] FOR LOGIN [REPORTUSER]
            WITH DEFAULT_SCHEMA = [dbo];
        END;

        IF (
               NOT EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'SQL_USER'
                  AND [name] = 'ohamci'
        )
               AND EXISTS(SELECT 1 FROM [sys].[databases] WHERE [name] = 'OHAMCI')
           )
        BEGIN
            CREATE USER [ohamci] FOR LOGIN [ohamci] WITH DEFAULT_SCHEMA = [dbo];
        END;

        IF (
               NOT EXISTS
        (
            SELECT 1
            FROM [sys].[database_principals]
            WHERE [type_desc] = 'SQL_USER'
                  AND [name] = 'svc_sqlmciview'
        )
               AND EXISTS(SELECT 1 FROM [sys].[databases] WHERE [name] = 'OHAMCIViews')
           )
        BEGIN
            CREATE USER [svc_sqlmciview] FOR LOGIN [svc_sqlmciview]
            WITH DEFAULT_SCHEMA = [dbo];
        END;
    END;

    --GRANT ADMIN PERMISSIONS
    BEGIN
        EXEC sp_addsrvrolemember 'IDBA', 'sysadmin';
    END;

    --GRANT PERMISSION
    IF (ISNULL([sys].[fn_hadr_is_primary_replica](DB_NAME()), 1) = 1)
    BEGIN
        IF (@Instance = 'DEV')
        BEGIN
            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_dbappuser_ied';

			EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_db_ttuser1_ied';

			EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_db_ttuser2_ied';

			EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_db_ttuser3_ied';

			EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_db_ttuser4_ied';

			EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_db_ttuser5_ied';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_dbat_ied_ad';

            EXEC sp_addrolemember 'db_ddladmin', 'ONE\svc_dbat_ied_ad';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_bt_inp_ad_ied';

            EXEC sp_addrolemember 'db_ddladmin', 'ONE\svc_bt_inp_ad_ied';

            EXEC sp_addrolemember 'db_owner', 'ONE\svc_bt_inp_ad_ied';

			EXEC sp_addrolemember 'DBReportUsrRole', 'ONE\svc_sqlreport_ied';

			EXEC sp_addrolemember 'DBExecuteRole', 'ONE\svc_sqlreport_ied';

			EXEC sp_addrolemember 'DBAlterRole', '_developer';
        END;

        IF (@Instance = 'TEST')
        BEGIN
            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_dbappuser_iet';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_dbappuser1_iet';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_dbappuser2_iet';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_dbappuser3_iet';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_dbappuser4_iet';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_dbappuser5_iet';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_db_ttuser1_iet';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_db_ttuser2_iet';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_db_ttuser3_iet';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_db_ttuser4_iet';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_db_ttuser5_iet';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_dbat_iet_ad';

            EXEC sp_addrolemember 'db_ddladmin', 'ONE\svc_dbat_iet_ad';

            EXEC sp_addrolemember 'DBAppUsrRole', 'ONE\svc_bt_inp_ad_iet';

            EXEC sp_addrolemember 'db_ddladmin', 'ONE\svc_bt_inp_ad_iet';

            EXEC sp_addrolemember 'db_owner', 'ONE\svc_bt_inp_ad_iet';

			EXEC sp_addrolemember 'DBReportUsrRole', 'ONE\svc_sqlreport_iet';

			EXEC sp_addrolemember 'DBExecuteRole', 'ONE\svc_sqlreport_iet';

			EXEC sp_addrolemember 'DBAlterRole', '_tester';
        END;

        EXEC sp_addrolemember 'DBAppUsrRole', '_developer';

        EXEC sp_addrolemember 'DBAppUsrRole', '_tester';

        EXEC sp_addrolemember 'DBReportUsrRole', 'REPORTUSER';

		EXEC sp_addrolemember 'DBExecuteRole', 'REPORTUSER';
		
        IF (DB_NAME() = 'OHAMCI')
        BEGIN
            EXEC sp_addrolemember 'DBAppUsrRole', 'ohamci';

            EXEC sp_addrolemember 'db_ddladmin', 'ohamci';
        END;

		IF (DB_NAME() != 'OHAMCI' AND EXISTS(SELECT 1 FROM [sys].[databases] WHERE [name] = 'OHAMCI'))
		BEGIN
            EXEC sp_addrolemember 'DBAppUsrRole', 'ohamci';
        END;

        IF (DB_NAME() = 'OHAMCIViews')
        BEGIN
            EXEC sp_addrolemember 'DBAppUsrRole', 'svc_sqlmciview';

            EXEC sp_addrolemember 'db_ddladmin', 'svc_sqlmciview';
        END;

		IF (DB_NAME() != 'OHAMCIViews' AND EXISTS(SELECT 1 FROM [sys].[databases] WHERE [name] = 'OHAMCIViews'))
        BEGIN
            EXEC sp_addrolemember 'DBAppUsrRole', 'svc_sqlmciview';
        END;
    END;
END;